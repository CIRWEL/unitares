# Coherence Discontinuity and Health Status Inconsistency Fix

**Date:** 2025-11-25  
**Discovered by:** Haiku agent `hikewa_unitares_governance`  
**Status:** ✅ Fixed

---

## Critical Bugs Found

### Bug 1: Coherence Discontinuity

**Symptom:**
- Coherence drops from 0.64 to 0.49 in a single update (50% drop)
- Cannot be explained by gradual thermodynamic drift
- Both `hikewa_unitares_governance` and `Eno_Richter_Claude_CLI` experienced same discontinuity

**Root Cause:**
1. Old state files saved coherence = 0.64 (from blended calculation: `0.7 * C(V) + 0.3 * param_coherence`)
2. When state loaded from disk, coherence stays at 0.64
3. Coherence only recalculated in `update_dynamics()` using pure C(V)
4. First update after loading recalculates to pure C(V) ≈ 0.49
5. **Result:** Discontinuity from 0.64 → 0.49

**Evidence:**
```
Update 1: coherence 0.649 (from old state file)
Update 2: coherence 0.490 (recalculated to pure C(V))
```

**Fix:**
- Recalculate coherence immediately when loading state from disk
- Use current V and theta to compute pure C(V) on load
- Prevents discontinuity by ensuring coherence matches current state

**Code Change:**
```python
# Before: Load old coherence value
state.coherence = float(data.get('coherence', 1.0))

# After: Recalculate from current V
from governance_core.coherence import coherence as coherence_func
from governance_core.parameters import DEFAULT_PARAMS
recalculated_coherence = coherence_func(state.V, state.unitaires_theta, DEFAULT_PARAMS)
state.coherence = float(np.clip(recalculated_coherence, 0.0, 1.0))
```

---

### Bug 2: Health Status Inconsistency

**Symptom:**
- `process_agent_update` returns `health_status: "degraded"` for risk 0.31-0.50
- `aggregate_metrics` shows all agents as `"healthy"`
- `list_agents` shows `health_status: "unknown"`

**Root Cause:**
Different health status calculations using different thresholds:

1. **`health_checker.get_health_status()`** (used by `process_agent_update`):
   - `risk_healthy_max = 0.30` (< 0.30: healthy)
   - `risk_degraded_max = 0.60` (0.30-0.60: degraded, ≥0.60: critical)

2. **`get_metrics()`** (used by `aggregate_metrics`):
   - Uses `RISK_REVISE_THRESHOLD = 0.50` (> 0.50: degraded)
   - No critical threshold based on risk

**Result:**
- Risk 0.31-0.50: `health_checker` says "degraded", `get_metrics()` says "healthy"
- Risk 0.51-0.60: Both say "degraded"
- Risk > 0.60: `health_checker` says "critical", `get_metrics()` says "degraded"

**Fix:**
- Align `get_metrics()` and `process_update()` to use same thresholds as `health_checker`
- Use `risk_healthy_max=0.30` and `risk_degraded_max=0.60` consistently

**Code Changes:**
```python
# In get_metrics() and process_update():
from src.health_thresholds import HealthThresholds
health_checker = HealthThresholds()

if void_active or coherence < COHERENCE_CRITICAL_THRESHOLD:
    status = 'critical'
elif risk_score >= health_checker.risk_degraded_max:  # >= 0.60: critical
    status = 'critical'
elif risk_score >= health_checker.risk_healthy_max:  # 0.30-0.60: degraded
    status = 'degraded'
else:  # < 0.30: healthy
    status = 'healthy'
```

---

## Impact

### Before Fix:
- **Coherence discontinuity:** Agents see sudden 50% coherence drop on first update after state load
- **Health status confusion:** Different tools show different health status for same agent
- **Calibration issues:** Cannot trust coherence or health status values

### After Fix:
- **Coherence continuity:** Coherence recalculated on load, no discontinuity
- **Consistent health status:** All tools use same thresholds
- **Reliable metrics:** Coherence and health status can be trusted

---

## Testing

**Test Case 1: State Load Coherence**
```python
# Load state with old coherence = 0.64
state = load_monitor_state(agent_id)
# Should recalculate to pure C(V) immediately
assert abs(state.coherence - pure_C_V(state.V)) < 0.01
```

**Test Case 2: Health Status Consistency**
```python
# Risk = 0.35 (between 0.30 and 0.60)
metrics = monitor.get_metrics()
health_status, _ = health_checker.get_health_status(risk_score=0.35)
# Both should say "degraded"
assert metrics['status'] == health_status.value == "degraded"
```

---

## Related Issues

- **Pure coherence implementation:** Removed `param_coherence` blend, but didn't fix state loading
- **Health threshold recalibration:** Thresholds updated but not consistently applied
- **State persistence:** Old blended coherence values persisted in state files

---

## Status

✅ **Fixed** - Coherence recalculated on load, health status thresholds aligned

**Next Steps:**
- Monitor for coherence discontinuities (should be none)
- Verify health status consistency across tools
- Consider migration script to recalculate coherence in existing state files

