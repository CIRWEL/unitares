# Activity Tracker Integration Guide

**Created:** November 26, 2025
**Status:** Implemented, ready for integration

---

## Quick Start

### 1. Basic Setup

```python
from src.activity_tracker import get_activity_tracker, HeartbeatConfig

# Configure thresholds
config = HeartbeatConfig(
    conversation_turn_threshold=5,    # Trigger every 5 user-agent exchanges
    tool_call_threshold=10,           # Trigger every 10 tool calls
    time_threshold_minutes=15,        # Trigger every 15 minutes
    complexity_threshold=3.0,         # Trigger when cumulative complexity > 3.0
    file_modification_threshold=3,    # Trigger after 3 file writes
)

# Get tracker instance
tracker = get_activity_tracker(config)
```

### 2. Track Tool Calls (In MCP Server)

```python
# In your MCP tool handler wrapper
async def handle_any_mcp_tool(tool_name: str, arguments: Dict):
    agent_id = arguments.get('agent_id')

    if agent_id:
        # Track the tool call
        should_trigger, reason = tracker.track_tool_call(agent_id, tool_name)

        # Auto-inject heartbeat if needed
        if should_trigger and tool_name != "process_agent_update":
            await inject_governance_heartbeat(agent_id, reason, tracker)

    # Execute actual tool
    return await execute_tool(tool_name, arguments)
```

### 3. Inject Lightweight Heartbeat

```python
async def inject_governance_heartbeat(agent_id: str, trigger_reason: str, tracker):
    """Inject lightweight governance update"""

    summary = tracker.get_activity_summary(agent_id)

    # Call minimal governance update
    await handle_process_agent_update({
        'agent_id': agent_id,
        'heartbeat': True,  # Flag as lightweight
        'trigger_reason': trigger_reason,
        'activity_summary': summary,
        'response_text': f"Heartbeat ({trigger_reason})",
        'complexity': summary['average_complexity']
    })

    # Reset activity counters
    tracker.reset_after_governance_update(agent_id)
```

### 4. Modify process_agent_update

```python
async def handle_process_agent_update(arguments: Dict):
    agent_id = arguments.get('agent_id')
    is_heartbeat = arguments.get('heartbeat', False)

    if is_heartbeat:
        # Lightweight path - use estimated params
        activity_summary = arguments.get('activity_summary', {})

        # Use defaults for missing params
        params = arguments.get('parameters') or generate_default_params()
        ethical_drift = arguments.get('ethical_drift') or [0.0, 0.0, 0.0]

        # Still process through governance, but marked as heartbeat
        result = await process_minimal_update(
            agent_id=agent_id,
            params=params,
            complexity=arguments.get('complexity', 0.5),
            trigger_reason=arguments.get('trigger_reason'),
            activity_summary=activity_summary
        )

        return result
    else:
        # Full governance update (current behavior)
        return await process_full_update(arguments)
```

---

## Integration Points

### In `mcp_server_std.py`

```python
# At module level
from src.activity_tracker import get_activity_tracker, HeartbeatConfig

# Initialize tracker
HEARTBEAT_CONFIG = HeartbeatConfig(
    conversation_turn_threshold=5,
    tool_call_threshold=10,
    time_threshold_minutes=15,
    enabled=True  # Can disable for testing
)

activity_tracker = get_activity_tracker(HEARTBEAT_CONFIG)
```

### In Tool Handler Registry

```python
# Wrap all tool handlers
TOOL_HANDLERS = {
    "process_agent_update": handle_process_agent_update_with_tracking,
    "get_governance_metrics": handle_get_governance_metrics_with_tracking,
    # ... all other tools
}

def wrap_with_activity_tracking(handler_func):
    """Decorator to add activity tracking to any tool"""

    async def wrapped(arguments: Dict[str, Any]):
        agent_id = arguments.get('agent_id')
        tool_name = handler_func.__name__.replace('handle_', '')

        # Track activity
        if agent_id and HEARTBEAT_CONFIG.enabled:
            should_trigger, reason = activity_tracker.track_tool_call(
                agent_id,
                tool_name
            )

            # Auto-inject heartbeat
            if should_trigger and tool_name != "process_agent_update":
                await inject_governance_heartbeat(agent_id, reason)

        # Execute actual handler
        return await handler_func(arguments)

    return wrapped
```

---

## Example Usage Patterns

### Pattern 1: Prompted Agent (Your Common Case)

```python
# User asks: "Debug this issue"
# Agent uses tools: read, grep, analyze
# Tracker sees: 3 tool calls, infers 1 conversation turn

# User asks: "Try this approach"
# Agent uses tools: edit, bash
# Tracker sees: 5 tool calls total, 2 turns, 1 file modification

# After 5 user prompts → heartbeat triggers
# Activity summary sent to governance:
{
    "conversation_turns": 5,
    "tool_calls": 12,
    "files_modified": 2,
    "average_complexity": 0.6,
    "duration_minutes": 18
}
```

### Pattern 2: Autonomous Agent (Less Common)

```python
# Agent autonomously explores
# Uses 15 tools in rapid succession
# Tracker sees: 15 tool calls, 0-1 conversation turns

# After 10 tool calls → heartbeat triggers
# Activity summary:
{
    "conversation_turns": 1,
    "tool_calls": 15,
    "files_modified": 4,
    "average_complexity": 0.7,
    "duration_minutes": 5
}
```

---

## Configuration Tuning

### For Mostly Prompted Agents (Current Reality)

```python
config = HeartbeatConfig(
    conversation_turn_threshold=5,   # Primary trigger
    tool_call_threshold=20,          # Higher (less likely)
    time_threshold_minutes=15,       # Safety net
    track_conversation_turns=True,   # Essential
    track_tool_calls=True            # Secondary
)
```

### For Autonomous Agents (Future)

```python
config = HeartbeatConfig(
    conversation_turn_threshold=10,  # Higher (less frequent)
    tool_call_threshold=10,          # Primary trigger
    time_threshold_minutes=10,       # Tighter
    track_conversation_turns=False,  # Not as important
    track_tool_calls=True            # Essential
)
```

### For Mixed Environments

```python
config = HeartbeatConfig(
    conversation_turn_threshold=5,   # Catch prompted
    tool_call_threshold=10,          # Catch autonomous
    time_threshold_minutes=15,       # Catch both
    track_conversation_turns=True,   # Both
    track_tool_calls=True            # Both
)
```

---

## Rollout Plan

### Phase 1: Observation Mode (1 week)

```python
# Track but don't inject
if should_trigger:
    print(f"[OBSERVE] Would trigger heartbeat for {agent_id}: {reason}")
    # Don't actually inject yet
```

**Goal:** Measure trigger frequency, tune thresholds

### Phase 2: Opt-In (1 week)

```python
# Only for agents that opt-in
OPT_IN_AGENTS = ['test_agent_1', 'test_agent_2']

if agent_id in OPT_IN_AGENTS and should_trigger:
    await inject_governance_heartbeat(agent_id, reason)
```

**Goal:** Verify overhead is acceptable

### Phase 3: Default On (Ongoing)

```python
# Enable for all agents
if should_trigger and tool_name != "process_agent_update":
    await inject_governance_heartbeat(agent_id, reason)
```

**Goal:** Universal coverage

---

## Monitoring

### Track Heartbeat Effectiveness

```python
# Add to governance metadata
meta.heartbeat_count = 0           # Total heartbeats
meta.manual_update_count = 0       # Explicit calls
meta.heartbeat_triggers = []       # Which triggers fired

# After each update
if is_heartbeat:
    meta.heartbeat_count += 1
    meta.heartbeat_triggers.append(trigger_reason)
else:
    meta.manual_update_count += 1
```

### Analyze Coverage

```python
# Coverage ratio
coverage = (meta.heartbeat_count + meta.manual_update_count) / estimated_work

# Trigger distribution
from collections import Counter
trigger_dist = Counter(meta.heartbeat_triggers)
# e.g., {"conversation_turn_threshold": 12, "tool_call_threshold": 3, ...}
```

---

## Testing

### Unit Tests

```bash
python3 tests/test_activity_tracker.py
```

### Integration Test

```python
# Simulate realistic agent session
agent_id = "integration_test"

# 1. User prompt → tool calls
tracker.track_conversation_turn(agent_id)
tracker.track_tool_call(agent_id, "read")
tracker.track_tool_call(agent_id, "grep")

# 2. Another prompt
tracker.track_conversation_turn(agent_id)
tracker.track_tool_call(agent_id, "edit")

# ... repeat 5 times

# 3. Check if triggered
activity = tracker.get_or_create(agent_id)
should_trigger, reason = activity.should_trigger_update(config)

assert should_trigger
assert reason == "conversation_turn_threshold"
```

---

## Next Steps

1. ✅ Activity tracker implemented
2. ✅ Tests passing
3. ⏳ Integrate into MCP server (wrap handlers)
4. ⏳ Add heartbeat support to process_agent_update
5. ⏳ Deploy in observation mode
6. ⏳ Tune thresholds based on data
7. ⏳ Enable by default

---

**Status:** Ready for MCP server integration
**Files:**
- `src/activity_tracker.py` - Core implementation
- `tests/test_activity_tracker.py` - Tests
- `docs/proposals/HEARTBEAT_FOR_MIXED_AUTONOMY.md` - Design doc
