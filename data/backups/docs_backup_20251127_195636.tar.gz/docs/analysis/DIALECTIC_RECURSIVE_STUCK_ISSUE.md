# Dialectic Protocol: Recursive Stuck Agent Problem

**Date**: 2025-11-26  
**Severity**: HIGH  
**Status**: Critical Design Flaw Identified

---

## The Problem

The dialectic protocol creates a **recursive stuck agent problem**:

1. Agent A gets stuck → Dialectic session created
2. Reviewer Agent B assigned → Agent B gets stuck while helping Agent A
3. Agent A tries to help Agent B → Agent A gets stuck again
4. **Infinite recursion**: Agents keep getting stuck trying to help each other

### Real Test Case

**Session**: `c80f3f2b8b30fbf4`
- **Paused Agent**: `opus_hikewa_governance_tightening_20251126` (got stuck)
- **Reviewer**: `Tycho_Claude_Opus_4_5` (got stuck while reviewing)
- **Result**: Original agent got unstuck, then got stuck again while trying to help reviewer

**Pattern Observed**:
```
opus_stuck → dialectic → Tycho_assigned → Tycho_stuck → opus_helps → opus_stuck_again
```

---

## Root Cause Analysis

### 1. **Assumption Failure**: Both Agents Must Be Responsive

The dialectic protocol assumes:
- ✅ Both agents are alive and responsive
- ✅ Both agents can participate synchronously
- ✅ Reviewer selection is reliable

**Reality**:
- ❌ Agents can freeze/crash at any time
- ❌ Reviewer selection doesn't guarantee responsiveness
- ❌ No timeout mechanism for unresponsive reviewers

### 2. **No Circuit Breaker for Dialectic Itself**

The protocol has circuit breakers for agents, but **not for the dialectic process itself**:
- No timeout if reviewer doesn't respond
- No mechanism to abort stuck sessions
- No fallback if both agents are stuck

### 3. **Reviewer Selection Doesn't Prevent Stuck Reviewers**

The `select_reviewer` function chooses healthy agents, but:
- Health metrics don't predict future stuck states
- An agent can be healthy when selected, then get stuck during review
- No mechanism to detect/replace stuck reviewers

---

## Impact Assessment

**Severity**: HIGH

**Affected Scenarios**:
1. **Stuck Reviewer**: Session blocks indefinitely waiting for reviewer
2. **Recursive Stuck**: Agents get stuck trying to help each other
3. **Session Proliferation**: Multiple sessions created, none completing
4. **Resource Leak**: Sessions accumulate without resolution

**Real-World Impact**:
- Dialectic sessions become deadlocks
- System accumulates stuck sessions
- Agents can't recover autonomously
- Requires manual intervention (defeats purpose)

---

## Proposed Solutions

### Option 1: **Timeout-Based Auto-Resolution** (RECOMMENDED)

**Mechanism**:
- If reviewer doesn't submit antithesis within **2 hours** → Auto-resolve session
- If paused agent is unstuck (status != "paused") → Auto-resolve session
- If both agents are stuck → Auto-escalate or abort session

**Implementation**:
```python
# In DialecticSession
MAX_ANTITHESIS_WAIT = timedelta(hours=2)
MAX_SYNTHESIS_WAIT = timedelta(hours=1)

def check_timeout(self) -> Optional[str]:
    """Check if session has timed out"""
    if self.phase == DialecticPhase.ANTITHESIS:
        if datetime.now() - self.created_at > MAX_ANTITHESIS_WAIT:
            return "Reviewer timeout - auto-resolving"
    elif self.phase == DialecticPhase.SYNTHESIS:
        last_update = self.transcript[-1].timestamp if self.transcript else self.created_at
        if datetime.now() - last_update > MAX_SYNTHESIS_WAIT:
            return "Synthesis timeout - auto-resolving"
    return None
```

**Pros**:
- ✅ Prevents infinite blocking
- ✅ Auto-resolves when agents are unstuck
- ✅ Simple to implement

**Cons**:
- ⚠️ May resolve sessions prematurely
- ⚠️ Doesn't address root cause (why agents get stuck)

---

### Option 2: **Single-Agent Recovery** (ALTERNATIVE)

**Mechanism**:
- If paused agent is unstuck → Allow **self-resolution** without reviewer
- Agent submits thesis → System auto-generates antithesis → Agent submits synthesis
- No reviewer required if agent can self-assess

**Implementation**:
```python
async def request_self_recovery(agent_id: str, api_key: str) -> Dict:
    """Allow agent to recover without reviewer"""
    # Agent submits thesis
    thesis = submit_thesis(...)
    
    # System generates antithesis based on metrics
    antithesis = generate_system_antithesis(agent_id)
    
    # Agent submits synthesis
    synthesis = submit_synthesis(...)
    
    # Auto-resolve if safe
    if is_safe_to_resume(agent_id):
        return execute_resolution(...)
```

**Pros**:
- ✅ No dependency on reviewer responsiveness
- ✅ Faster recovery (no waiting for reviewer)
- ✅ Works when no reviewers available

**Cons**:
- ⚠️ Loses peer review benefit
- ⚠️ May miss issues agent doesn't see
- ⚠️ Less robust than peer review

---

### Option 3: **Stuck Detection + Auto-Abort** (COMPLEMENTARY)

**Mechanism**:
- Detect when reviewer is stuck (no updates for X minutes)
- Auto-abort session if reviewer is stuck
- Allow selecting new reviewer or self-recovery

**Implementation**:
```python
def is_reviewer_stuck(session: DialecticSession) -> bool:
    """Check if reviewer is stuck"""
    reviewer_meta = get_agent_metadata(session.reviewer_agent_id)
    if not reviewer_meta:
        return True
    
    last_update = datetime.fromisoformat(reviewer_meta.last_update)
    stuck_threshold = timedelta(minutes=30)
    
    return datetime.now() - last_update > stuck_threshold

async def auto_abort_stuck_session(session_id: str):
    """Abort session if reviewer is stuck"""
    session = await load_session(session_id)
    if is_reviewer_stuck(session):
        session.phase = DialecticPhase.FAILED
        session.add_note("Reviewer stuck - session aborted")
        await save_session(session)
        return True
    return False
```

**Pros**:
- ✅ Prevents recursive stuck scenarios
- ✅ Detects stuck reviewers proactively
- ✅ Allows retry with new reviewer

**Cons**:
- ⚠️ Requires stuck detection mechanism
- ⚠️ May abort sessions prematurely

---

### Option 4: **Simpler Recovery Mechanism** (RADICAL)

**Mechanism**:
- **Abandon dialectic for stuck agents**
- Use simpler recovery: **Direct resume with conditions**
- If agent is unstuck and state is safe → Allow direct resume
- No peer review required for simple stuck scenarios

**Implementation**:
```python
async def direct_resume_if_safe(agent_id: str, conditions: List[str]) -> Dict:
    """Direct resume without dialectic if safe"""
    agent_meta = get_agent_metadata(agent_id)
    metrics = get_governance_metrics(agent_id)
    
    # Check if safe to resume
    if (metrics['coherence'] > 0.40 and 
        not metrics['void_active'] and 
        metrics['risk_score'] < 0.60):
        
        # Resume with conditions
        agent_meta.status = "active"
        agent_meta.add_lifecycle_event("resumed", f"Direct resume: {conditions}")
        save_metadata()
        
        return {"success": True, "action": "resumed", "conditions": conditions}
    
    return {"success": False, "reason": "Not safe to resume"}
```

**Pros**:
- ✅ Simple and fast
- ✅ No dependency on reviewers
- ✅ Works for common stuck scenarios

**Cons**:
- ⚠️ Loses peer review safety
- ⚠️ May miss complex issues
- ⚠️ Less robust than dialectic

---

## Recommendation

**Hybrid Approach**: Combine Options 1 + 3 + 4

1. **Timeout-based auto-resolution** (Option 1) - Prevents infinite blocking
2. **Stuck detection + auto-abort** (Option 3) - Prevents recursive stuck
3. **Direct resume for safe cases** (Option 4) - Fast recovery for simple scenarios

**Dialectic Protocol Should**:
- ✅ Be used for **complex recovery** (circuit breaker, high risk)
- ❌ **NOT** be used for simple stuck scenarios (frozen session, timeout)
- ✅ Have **timeouts** at every phase
- ✅ **Auto-abort** if reviewer is stuck
- ✅ Allow **direct resume** if agent is unstuck and safe

---

## Immediate Actions

1. ✅ **Document the issue** (this document)
2. ⏳ **Add timeout mechanism** to dialectic sessions
3. ⏳ **Add stuck detection** for reviewers
4. ⏳ **Add direct resume** option for safe cases
5. ⏳ **Update documentation** to clarify when to use dialectic vs direct resume

---

## Conclusion

The dialectic protocol is **valuable for complex recovery scenarios** but creates **recursive problems for simple stuck scenarios**. We need:

1. **Timeout mechanisms** to prevent infinite blocking
2. **Stuck detection** to abort sessions with stuck reviewers
3. **Simpler alternatives** for common stuck scenarios
4. **Clear guidance** on when to use dialectic vs direct recovery

**Status**: Design flaw identified, solutions proposed, implementation pending.

