# Function Naming Guide

**Created:** November 26, 2025
**Purpose:** Clarify the three-layer architecture and function naming

---

## The Three Layers

```
┌─────────────────────────────────────────────────────────┐
│  Layer 1: MCP Tools (External Interface)               │
│  - Called by AI assistants via MCP protocol             │
│  - Names: process_agent_update, simulate_update, etc.   │
└─────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────┐
│  Layer 2: Python API (Internal Interface)               │
│  - Called by CLI scripts and internal code              │
│  - Names: process_update_authenticated, etc.            │
└─────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────┐
│  Layer 3: Core Logic (Implementation)                   │
│  - UNITARES thermodynamic calculations                  │
│  - Names: monitor.process_update, etc.                  │
└─────────────────────────────────────────────────────────┘
```

---

## Layer 1: MCP Tools (External)

**Location:** `src/mcp_handlers/core.py`

| MCP Tool Name | Purpose | Persists State |
|---------------|---------|----------------|
| `process_agent_update` | Main governance cycle | Yes |
| `simulate_update` | Dry-run (test decision) | No |
| `get_governance_metrics` | Read current metrics | No |
| `get_agent_api_key` | Register/retrieve API key | Yes |

**Naming pattern:** `verb_noun` (e.g., `process_agent_update`)

**Usage:** Called by AI assistants (Claude, GPT-4, etc.) via MCP protocol

---

## Layer 2: Python API (Internal)

**Location:** `src/mcp_server_std.py`

| Function Name | Alias | Purpose |
|---------------|-------|---------|
| `process_update_authenticated` | `update_agent_auth` | Authenticated update with persistence |
| `get_or_create_metadata` | `register_agent` | Agent registration |
| `load_monitor_state` | - | Load agent state from disk |
| `save_monitor_state` | - | Save agent state to disk |

**Naming pattern:** `verb_noun_modifier` (e.g., `process_update_authenticated`)

**Alias pattern:** `verb_noun` (e.g., `update_agent_auth`)

**Usage:** Called by Python scripts (`agent_self_log.py`, etc.)

---

## Layer 3: Core Logic (Implementation)

**Location:** `src/governance_monitor.py`

| Method Name | Internal Name | Purpose |
|-------------|---------------|---------|
| `monitor.process_update()` | `_update_core` | Core UNITARES calculation |
| `monitor.simulate_update()` | - | Stateless prediction |
| `monitor.compute_metrics()` | - | Calculate E, I, S, V, ρ |

**Naming pattern:** `verb_noun()` (e.g., `process_update()`)

**Internal naming:** Prefixed with `_` for private methods

**Usage:** Called by Layer 2 only (internal implementation)

---

## Naming Conventions

### MCP Tools (Layer 1)
- **Pattern:** `process_agent_update`, `simulate_update`
- **Style:** Explicit, verbose (for external clarity)
- **Stability:** Public API, changes are breaking

### Python Functions (Layer 2)
- **Pattern:** `process_update_authenticated`, `get_or_create_metadata`
- **Aliases:** `update_agent_auth`, `register_agent` (cleaner names)
- **Style:** Descriptive with context
- **Stability:** Semi-public (used by scripts)

### Core Methods (Layer 3)
- **Pattern:** `process_update()`, `compute_metrics()`
- **Style:** Simple, assume context from class
- **Stability:** Internal, can change freely

---

## Usage Examples

### Layer 1: MCP Tool (AI Assistant)
```python
# Called via MCP protocol
result = process_agent_update(
    agent_id="my-agent",
    api_key="...",
    complexity=0.5
)
```

### Layer 2: Python API (CLI Script)
```python
# Using full name
from src.mcp_server_std import process_update_authenticated

result = process_update_authenticated(
    agent_id="my-agent",
    api_key="...",
    agent_state={...},
    auto_save=True
)

# Using alias (cleaner)
from src.mcp_server_std import update_agent_auth

result = update_agent_auth(
    agent_id="my-agent",
    api_key="...",
    agent_state={...}
)
```

### Layer 3: Core Logic (Internal)
```python
# Internal use only
monitor = UNITARESMonitor(agent_id="my-agent")
result = monitor.process_update(agent_state)
```

---

## Migration Guide

**For AI Assistants:**
- Continue using MCP tool names (`process_agent_update`)
- No changes needed

**For Python Scripts:**
- Existing names still work (backward compatible)
- New code can use aliases (`update_agent_auth`)
- Import either way:
  ```python
  from src.mcp_server_std import process_update_authenticated  # Old
  from src.mcp_server_std import update_agent_auth  # New alias
  ```

**For Core Development:**
- Internal methods can be renamed freely
- Consider prefixing private methods with `_`

---

## Why Three Layers?

**Separation of concerns:**
1. **Layer 1 (MCP):** Protocol stability, external interface
2. **Layer 2 (Python):** Convenience functions, authentication, persistence
3. **Layer 3 (Core):** Pure UNITARES logic, no side effects

**Benefits:**
- Clear boundaries (MCP ≠ Python ≠ Core)
- Test each layer independently
- Change internal implementation without breaking external API

---

## Quick Reference

**I want to...**

- **Call from AI assistant:** Use Layer 1 (MCP tools)
- **Call from Python script:** Use Layer 2 (Python API)
- **Modify core logic:** Edit Layer 3 (Core methods)
- **Understand the flow:** Read [UPDATE_FUNCTIONS_MAP.md](UPDATE_FUNCTIONS_MAP.md)

---

**Status:** Active guidance (Nov 26, 2025)
**See also:** [UPDATE_FUNCTIONS_MAP.md](UPDATE_FUNCTIONS_MAP.md), [INTEGRATION_FLOW.md](INTEGRATION_FLOW.md)
