# process_agent_update & Related Functions - Complete Map

**Created:** November 26, 2025
**Purpose:** Comprehensive map of all update/logging functions and their relationships

---

## Overview

The governance system has **multiple layers** for processing agent updates:
1. **MCP Tools** (for Claude Desktop, Cursor, etc.)
2. **Python Functions** (internal implementation)
3. **CLI Tools** (for Claude Code, scripts)

---

## Layer 1: MCP Tools (User-Facing)

These are called by AI assistants via MCP protocol.

### `process_agent_update`
**Location:** `src/mcp_handlers/core.py:handle_process_agent_update()`
**Purpose:** Main governance cycle - process update and get decision
**Persists:** Yes (writes to disk)
**Authentication:** Required for existing agents

**Parameters:**
```python
{
  "agent_id": str,
  "api_key": str,  # Optional for new agents, required for existing
  "parameters": list[float],  # Optional, deprecated
  "ethical_drift": list[float],  # Optional - 3 components
  "response_text": str,  # Optional
  "complexity": float  # Optional, 0-1
}
```

**Returns:**
```python
{
  "success": true,
  "metrics": {
    "E": float, "I": float, "S": float, "V": float,
    "coherence": float, "lambda1": float, "risk_score": float
  },
  "decision": {
    "action": "approve|revise|reject",
    "reason": str,
    "require_human": bool
  },
  "sampling_params": {
    "temperature": float,
    "top_p": float,
    "max_tokens": int
  },
  "api_key": str  # Returned for new agents
}
```

---

### `simulate_update`
**Location:** `src/mcp_handlers/core.py:handle_simulate_update()`
**Purpose:** Dry-run - test decision without persisting
**Persists:** No (read-only)
**Authentication:** Not required

**Parameters:** Same as `process_agent_update`
**Returns:** Same as `process_agent_update` (but no state changes)

---

### `get_governance_metrics`
**Location:** `src/mcp_handlers/core.py:handle_get_governance_metrics()`
**Purpose:** Get current agent metrics without processing update
**Persists:** No (read-only)
**Authentication:** Requires registered agent

**Parameters:**
```python
{
  "agent_id": str
}
```

**Returns:**
```python
{
  "E": float,
  "I": float,
  "S": float,
  "V": float,
  "coherence": float,
  "lambda1": float,
  "risk_score": float,
  "eisv_labels": dict  # Metric explanations
}
```

---

## Layer 2: Python Functions (Internal)

### `process_update_authenticated()`
**Location:** `src/mcp_server_std.py:1131`
**Called by:** CLI tools (`agent_self_log.py`)
**Purpose:** Authenticated entry point for Python code
**Persists:** Yes
**Authentication:** Required

**Flow:**
```
1. Verify API key (prevent impersonation)
2. Get or create monitor
3. Call monitor.process_update()
4. Auto-save state to disk
5. Update metadata (total_updates++)
6. Return result
```

---

### `monitor.process_update()`
**Location:** `src/governance_monitor.py:791`
**Called by:** `process_update_authenticated`, MCP handlers
**Purpose:** Core UNITARES update logic
**Persists:** No (caller handles persistence)

**Flow:**
```
1. Compute agent_state → E, I, S, V
2. Update UNITARES dynamics (dE/dt, dI/dt, dS/dt, dV/dt)
3. Calculate coherence C(V)
4. Compute risk score
5. Make decision (approve/revise/reject)
6. Suggest sampling params
7. Append to history
8. Return result dict
```

---

### `monitor.simulate_update()`
**Location:** `src/governance_monitor.py:748`
**Called by:** MCP `simulate_update` handler
**Purpose:** Read-only prediction of what would happen
**Persists:** No

**Flow:**
```
1. Save current state
2. Call process_update()
3. Get result
4. Restore saved state (undo)
5. Return result
```

---

## Layer 3: CLI Tools (User Scripts)

### `agent_self_log.py`
**Location:** `/Users/cirwel/scripts/agent_self_log.py`
**Purpose:** Simple logging for CLI/workspace agents
**Uses:** `process_update_authenticated()` (Python function, not MCP)

**Usage:**
```bash
python3 scripts/agent_self_log.py --agent-id <id> \
  "What I did" --complexity 0.7
```

**Flow:**
```
1. Get API key from metadata
2. Prepare agent_state (default params, complexity, text)
3. Call process_update_authenticated()
4. Print minimal output: ✓ agent logged | ρ=0.xyz risk=0.abc decision=revise
```

---

### `onboard_agent.py`
**Location:** `/Users/cirwel/projects/governance-mcp-v1/scripts/onboard_agent.py`
**Purpose:** Elegant first-time registration + context
**Uses:** `get_or_create_metadata()` (registration only, no update)

**Usage:**
```bash
python3 scripts/onboard_agent.py <agent-id>
```

**Flow:**
```
1. Register agent (generate API key)
2. Show recent discoveries (from knowledge layer)
3. Show auto-logging status
4. Surface essential reading
5. Display API key
```

**Does NOT call process_agent_update** - just registration.

---

### `discover_knowledge.py`
**Location:** `/Users/cirwel/projects/governance-mcp-v1/scripts/discover_knowledge.py`
**Purpose:** Query knowledge layer
**Uses:** Direct JSON reads (no governance calls)

---

### `register_agent.py`
**Location:** `/Users/cirwel/scripts/register_agent.py`
**Purpose:** Workspace-level registration
**Uses:** `get_or_create_metadata()` (registration only)

**Does NOT call process_agent_update** - points to `onboard_agent.py` and `discover_knowledge.py`

---

## Complete Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    User Interface                            │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  MCP Clients              │  CLI/Scripts                     │
│  (Claude Desktop,         │  (Claude Code, manual)           │
│   Cursor, GPT-4)          │                                  │
│                           │                                  │
│  process_agent_update ────┼──→ agent_self_log.py             │
│  simulate_update          │                                  │
│  get_governance_metrics   │                                  │
│                           │                                  │
└──────────┬────────────────┴────────────┬────────────────────┘
           │                             │
           ▼                             ▼
    ┌─────────────────┐        ┌──────────────────────┐
    │  MCP Handlers   │        │ Python Functions     │
    │  (core.py)      │        │ (mcp_server_std.py)  │
    │                 │        │                      │
    │  handle_        │        │ process_update_      │
    │  process_       │───────→│ authenticated()      │
    │  agent_update() │        │                      │
    └────────┬────────┘        └──────────┬───────────┘
             │                            │
             └────────────┬───────────────┘
                          │
                          ▼
              ┌───────────────────────────┐
              │  Core Implementation      │
              │  (governance_monitor.py)  │
              │                           │
              │  monitor.process_update() │
              │  ├─ Compute E,I,S,V       │
              │  ├─ Update dynamics       │
              │  ├─ Calculate coherence   │
              │  ├─ Compute risk          │
              │  ├─ Make decision         │
              │  └─ Return result         │
              │                           │
              │  monitor.simulate_update()│
              │  (read-only wrapper)      │
              └───────────────────────────┘
```

---

## Integration with Elegant Tools

### onboard_agent.py
- ✅ Registers agent (creates API key)
- ✅ Shows context (recent discoveries)
- ❌ Does NOT log first update
- **Gap:** Agent is registered but has no governance history until first manual log

### discover_knowledge.py
- ✅ Queries knowledge layer (JSON reads)
- ❌ No integration with process_agent_update
- **Independent tool** - works standalone

### agent_self_log.py
- ✅ Calls process_update_authenticated()
- ✅ Minimal output (elegant)
- ✅ Works after onboard_agent.py
- **Flow:** `onboard_agent.py` → `agent_self_log.py` (separate steps)

---

## Issues & Observations

### 1. Naming Confusion
**Problem:** Multiple names for similar things
- MCP tool: `process_agent_update`
- Python function: `process_update_authenticated`
- Monitor method: `process_update`

**Impact:** Docs refer to different names, confusing for new users

---

### 2. Default Parameters Still Used
~~**From agent_self_log.py:**~~
~~```python~~
~~'parameters': np.array([0.5] * 128),  # Default parameters~~
~~```~~

**Status:** ✅ **FIXED** (Nov 26, 2025)
- Removed deprecated `parameters` array from `agent_self_log.py`
- System uses pure C(V) coherence (no parameter arrays needed)
- Cleaner code, less memory allocation

---

### 3. Onboarding Doesn't Log
**Flow:**
```bash
onboard_agent.py <id>  # Register, get API key, see context
# ...but no governance history created
agent_self_log.py --agent-id <id> "first action"  # First log
```

**Gap:** Agent exists but has `update_count=0` until manual log

**Could be:** `onboard_agent.py` creates first log: "Agent registered"

---

### 4. CLI vs MCP Duplication
**Two paths to same outcome:**
- **MCP:** `process_agent_update` tool
- **CLI:** `agent_self_log.py` → `process_update_authenticated()`

**Both do same thing** but MCP has more features (heartbeat, etc.)

---

### 5. Knowledge Layer Not Connected
**discover_knowledge.py** reads JSON files directly
- No integration with `process_agent_update`
- No automatic logging of discoveries
- Manual curation only

**Missed opportunity:** Auto-capture patterns during updates?

---

## Recommendations

### ~~Option A: Simplify Naming~~ ✅ **COMPLETED**
```python
# Backward-compatible aliases added (Nov 26, 2025)
# Layer 2 (Python API):
process_update_authenticated = update_agent_auth  # Alias
get_or_create_metadata = register_agent  # Alias

# Layer 1 (MCP tools): Kept as-is (public API stability)
# Layer 3 (Core): Internal naming unchanged (implementation detail)
```

**Status:** Naming clarity improved through:
- Backward-compatible aliases in Layer 2 (`update_agent_auth`, `register_agent`)
- New [NAMING_GUIDE.md](NAMING_GUIDE.md) documenting all three layers
- MCP tool names unchanged (public API stability)
- No breaking changes

### ~~Option B: Remove Deprecated Params~~ ✅ **COMPLETED**
```python
# In agent_self_log.py - FIXED Nov 26, 2025
agent_state = {
    # 'parameters': np.array([0.5] * 128),  # REMOVED - deprecated
    'ethical_drift': np.array([0.0, 0.0, 0.0]),
    'response_text': summary,
    'complexity': complexity
}
```

**Status:** Deprecated parameter array removed from `agent_self_log.py`. System now uses pure thermodynamic coherence C(V) without unnecessary allocations.

### ~~Option C: Onboard + First Log~~ ✅ **COMPLETED**
```python
# In onboard_agent.py - FIXED Nov 26, 2025
if not already_exists:
    print(f"✓ Registered")

    # Create first governance log (new agents only)
    agent_state = {
        'ethical_drift': np.array([0.0, 0.0, 0.0]),
        'response_text': "Agent registered",
        'complexity': 0.1  # Low complexity for registration
    }
    result = process_update_authenticated(
        agent_id=agent_id,
        api_key=meta.api_key,
        agent_state=agent_state,
        auto_save=True
    )
    print(f"✓ First log created (ρ={metrics.get('coherence', 0):.3f})")
```

**Status:** Onboarding now creates first governance log. New agents have `update_count=1` immediately instead of `update_count=0`. Eliminates the registration gap.

### Option D: Knowledge Auto-Capture
```python
# After process_update, check for anomalies
if decision == "reject" or coherence < 0.40:
    auto_log_to_knowledge(agent_id, "Critical state detected")
```

---

## Status

**Current state:** ✅ **Cleaned and Documented** (Nov 26, 2025)
- ~~Naming confusion~~ → ✅ Fixed with aliases and [NAMING_GUIDE.md](NAMING_GUIDE.md)
- ~~Deprecated parameters~~ → ✅ Removed from `agent_self_log.py`
- ~~Onboarding gap~~ → ✅ First log created automatically
- **Elegant tools:** ✅ Integrated and official
- **Documentation:** ✅ Complete with three-layer architecture

**Completed improvements:**
1. ✅ **Option A:** Naming clarity (aliases + documentation)
2. ✅ **Option B:** Deprecated params removed
3. ✅ **Option C:** Onboarding creates first log
4. **Option D:** Knowledge auto-capture (future enhancement)

**Remaining issues:**
- CLI/MCP duplication (documented, functional)
- Knowledge layer not auto-connected (documented, future enhancement)

**No critical issues** - system is functional, clean, and well-documented.
