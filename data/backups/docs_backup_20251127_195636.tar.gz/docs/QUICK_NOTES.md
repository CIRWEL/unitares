# Quick Notes & Minor Issues

**Date:** 2025-11-25  
**Status:** Non-critical items worth noting

---

## ✅ System Status

**Major fixes completed:**
1. ✅ Tool timeout issues - fixed with timeout wrapper and async I/O
2. ✅ Coherence discontinuity - fixed by recalculating on load
3. ✅ Health status inconsistency - fixed by aligning thresholds
4. ✅ Circuit breaker formatting - fixed f-string syntax error

**System is substantially more reliable.**

---

## 📝 Minor Notes

### 1. Threshold Terminology (Documented, Intentional)

**Observation:** Two different risk thresholds serve different purposes:

- **Decision thresholds** (`RISK_REVISE_THRESHOLD = 0.50`):
  - Used for approve/revise/reject decisions
  - Stricter: < 0.30 approve, 0.30-0.50 revise, > 0.50 reject

- **Health status thresholds** (`risk_degraded_max = 0.60`):
  - Used for healthy/degraded/critical health status
  - More lenient: < 0.30 healthy, 0.30-0.60 degraded, ≥ 0.60 critical

**Why different?**
- Decisions need to be conservative (catch issues early)
- Health status is observational (monitoring, not blocking)
- This is intentional and documented

**Note:** Could be confusing - consider adding comment explaining the difference.

---

### 2. Dialectic Protocol Bug Workaround

**Location:** `src/mcp_handlers/dialectic.py:551`

**Issue:** Metadata sometimes contains strings instead of AgentMetadata objects.

**Current fix:** Workaround - skip invalid entries:
```python
if isinstance(agent_meta, str):
    # This is the bug - metadata contains strings instead of objects
    continue  # Skip invalid entries
```

**Status:** Handled gracefully, but root cause not fixed.

**Recommendation:** Investigate why metadata becomes strings (serialization issue?).

---

### 3. Minor TODOs

**Non-critical TODOs found:**

1. **`src/dialectic_protocol.py:600`**
   - TODO: Implement tag-based expertise matching
   - Status: Feature enhancement, not bug

2. **`src/mcp_handlers/dialectic.py:82`**
   - TODO: Implement full reconstruction
   - Status: Partial implementation works, full reconstruction not needed yet

3. **`src/mcp_handlers/dialectic.py:176`**
   - TODO: Verify API key
   - Status: API key validation exists, but could be more robust

**Recommendation:** These are feature enhancements, not bugs. Can be addressed when needed.

---

## 🔍 Potential Improvements (Not Bugs)

### 1. Threshold Documentation

**Suggestion:** Add clear documentation explaining:
- Why decision thresholds (0.30/0.50) differ from health thresholds (0.30/0.60)
- When each is used
- Rationale for the difference

**File:** `docs/guides/THRESHOLDS.md` (create if needed)

---

### 2. Metadata Type Safety

**Suggestion:** Add type checking/validation when loading metadata to prevent string conversion bug.

**File:** `src/mcp_handlers/dialectic.py`

---

### 3. Empirical Threshold Validation

**Note:** Thresholds (0.30/0.50/0.60) are based on observed distribution but not empirically validated.

**Status:** Documented in `docs/analysis/THRESHOLD_VALIDATION_PLAN.md`

**Recommendation:** Collect validation data over time to optimize thresholds.

---

## ✅ Summary

**No glaring bugs found.** System is in good shape after recent fixes.

**Minor items:**
- Threshold terminology could be clearer (documentation)
- Dialectic metadata bug has workaround (investigate root cause)
- Minor TODOs (non-critical features)

**Recommendation:** System is ready for use. Address minor items as time permits.

---

## 🎯 Quick Wins (If Time Permits)

1. **Add threshold documentation** (15 min)
   - Explain decision vs health thresholds
   - Add to README or guides

2. **Investigate metadata string bug** (30 min)
   - Trace where strings come from
   - Fix root cause if simple

3. **Add type hints** (ongoing)
   - Improve type safety
   - Help catch bugs early

---

**Status:** ✅ System is reliable and ready for production use.

