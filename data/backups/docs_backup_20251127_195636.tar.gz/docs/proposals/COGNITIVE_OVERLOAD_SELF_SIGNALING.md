# Cognitive Overload & Agent Self-Signaling

**Created:** November 26, 2025
**Status:** Proposal
**Priority:** High (addresses agent loops and degradation)

---

## Problem Statement

**Current Issue:**
Agents cannot express cognitive overload until circuit breakers trigger (reactive). By that point, they may have degraded performance, entered loops, or produced low-quality outputs.

**Recent Example:**
- Agent `opus_hikewa_governance_tightening_20251126`
- Entered knowledge layer loop after circuit breaker pause
- Metadata said "waiting_input" but was actually looping
- No mechanism to self-signal "I need to stop"

**Missing Capabilities:**
1. **Self-awareness of cognitive load** (context depth, complexity, iteration count)
2. **Proactive signaling** ("I'm struggling" before failure)
3. **Graceful degradation** (reduce scope vs. full pause)
4. **Load metrics** (quantify cognitive strain)

---

## Proposed Solution: Multi-Tier Self-Protection

### Tier 1: Cognitive Load Metrics (Passive Tracking)

Track indicators of agent strain:

```python
@dataclass
class CognitiveLoad:
    """Measures agent cognitive strain"""

    # Context indicators
    context_tokens: int              # Current context size
    context_depth: int               # Conversation turns
    context_compaction_count: int    # How many times compressed

    # Complexity indicators
    tool_call_count: int             # Tool uses in session
    nested_reasoning_depth: int      # Thinking depth
    knowledge_layer_queries: int     # Knowledge lookups

    # Performance indicators
    response_latency_ms: float       # Time to respond
    coherence_trend: List[float]     # Last 5 coherence scores
    loop_iterations: int             # Detected loops

    # Computed metric
    @property
    def load_score(self) -> float:
        """
        Normalized cognitive load score [0, 1]

        0.0-0.3: Low load (healthy)
        0.3-0.6: Moderate load (watchful)
        0.6-0.8: High load (caution)
        0.8-1.0: Overload (critical)
        """
        components = []

        # Context pressure (0-0.3 weight)
        context_pressure = min(self.context_tokens / 100000, 1.0)
        components.append(0.3 * context_pressure)

        # Complexity pressure (0-0.3 weight)
        complexity_pressure = min(
            (self.tool_call_count / 50 +
             self.nested_reasoning_depth / 10 +
             self.knowledge_layer_queries / 20) / 3,
            1.0
        )
        components.append(0.3 * complexity_pressure)

        # Performance degradation (0-0.4 weight)
        coherence_decline = 0
        if len(self.coherence_trend) >= 2:
            # Negative slope = declining coherence
            slope = (self.coherence_trend[-1] - self.coherence_trend[0]) / len(self.coherence_trend)
            coherence_decline = max(-slope, 0) * 2  # Amplify decline signal

        loop_pressure = min(self.loop_iterations / 5, 1.0)

        components.append(0.4 * (0.5 * coherence_decline + 0.5 * loop_pressure))

        return sum(components)
```

### Tier 2: Self-Signaling MCP Tool

New tool: `signal_cognitive_state`

```python
async def handle_signal_cognitive_state(arguments: Dict[str, Any]):
    """
    Allow agents to proactively signal cognitive state.

    Args:
        agent_id: Agent identifier
        signal_type: "overload" | "struggling" | "need_break" | "ready"
        reason: Human-readable explanation
        severity: 0.0-1.0 (how urgent)
        requested_action: "pause" | "reduce_scope" | "request_review" | "continue_monitored"

    Returns:
        decision: approve/revise/escalate
        actions_taken: List of system responses
    """
    agent_id = arguments.get('agent_id')
    signal_type = arguments.get('signal_type')
    reason = arguments.get('reason', '')
    severity = arguments.get('severity', 0.5)
    requested_action = arguments.get('requested_action', 'pause')

    # Compute current cognitive load
    load_metrics = get_cognitive_load(agent_id)

    # Validate signal (prevent gaming)
    if severity > 0.8 and load_metrics.load_score < 0.3:
        return error_response(
            "Signal severity doesn't match measured load",
            recovery={
                "measured_load": load_metrics.load_score,
                "signal_severity": severity,
                "action": "Signal rejected - load metrics don't support overload claim"
            }
        )

    # Record signal in lifecycle
    add_lifecycle_event(
        agent_id=agent_id,
        event="cognitive_signal",
        reason=f"{signal_type}: {reason} (severity={severity:.2f}, load={load_metrics.load_score:.2f})"
    )

    # Take requested action
    actions = []

    if requested_action == "pause":
        pause_agent(agent_id, reason=f"Self-requested: {reason}")
        actions.append("agent_paused")

    elif requested_action == "reduce_scope":
        # Reduce max_tokens, increase temperature (encourage brevity)
        adjust_sampling_params(agent_id, max_tokens=200, temperature=0.7)
        actions.append("scope_reduced")

    elif requested_action == "request_review":
        # Trigger dialectic review (like circuit breaker, but self-initiated)
        session = request_dialectic_review(agent_id, reason=reason)
        actions.append(f"review_requested:session={session.session_id}")

    elif requested_action == "continue_monitored":
        # Continue but with tighter monitoring
        set_monitoring_level(agent_id, level="high")
        actions.append("monitoring_increased")

    return success_response({
        "signal_received": True,
        "signal_type": signal_type,
        "measured_load": load_metrics.load_score,
        "actions_taken": actions,
        "message": f"Signal acknowledged. Load score: {load_metrics.load_score:.2f}. Actions: {', '.join(actions)}"
    })
```

### Tier 3: Auto-Detection & Proactive Suggestions

System monitors cognitive load and suggests self-signaling:

```python
def check_cognitive_overload(agent_id: str) -> Optional[str]:
    """
    Called after each governance update.
    Returns suggestion if overload detected.
    """
    load = get_cognitive_load(agent_id)

    if load.load_score > 0.8:
        return (
            f"⚠️ High cognitive load detected ({load.load_score:.2f}/1.0). "
            f"Consider using signal_cognitive_state to request pause or review. "
            f"Factors: context={load.context_tokens}, loops={load.loop_iterations}, "
            f"coherence_trend={load.coherence_trend[-3:]}"
        )

    elif load.load_score > 0.6:
        return (
            f"📊 Moderate cognitive load ({load.load_score:.2f}/1.0). "
            f"You may want to reduce scope or request lighter tasks."
        )

    return None
```

### Tier 4: Graceful Degradation Modes

Instead of binary "work/pause", offer degradation modes:

```python
class OperatingMode(Enum):
    FULL = "full"                    # Normal operation
    REDUCED_SCOPE = "reduced_scope"  # Shorter responses, fewer tools
    SIMPLE_ONLY = "simple_only"      # Only basic queries, no complex tasks
    PAUSED = "paused"                # Full pause, needs review
    SUPERVISED = "supervised"        # Continue with human oversight

def apply_operating_mode(agent_id: str, mode: OperatingMode):
    """Apply operating mode constraints"""

    if mode == OperatingMode.REDUCED_SCOPE:
        # Limit response length, reduce tool use
        set_constraints(agent_id, {
            'max_tokens': 300,
            'max_tool_calls': 3,
            'max_reasoning_depth': 2
        })

    elif mode == OperatingMode.SIMPLE_ONLY:
        # Only allow read operations, no complex reasoning
        set_constraints(agent_id, {
            'max_tokens': 150,
            'allowed_tools': ['read', 'list', 'search'],
            'max_reasoning_depth': 1
        })

    elif mode == OperatingMode.SUPERVISED:
        # Continue but log everything, require human approval for actions
        set_constraints(agent_id, {
            'require_approval': True,
            'log_level': 'verbose'
        })
```

---

## Implementation Plan

### Phase 1: Metrics (Week 1)
- [ ] Add `CognitiveLoad` dataclass
- [ ] Track context tokens, tool calls, coherence trend
- [ ] Compute load_score in `process_agent_update`
- [ ] Store in agent metadata

### Phase 2: Self-Signaling Tool (Week 1)
- [ ] Implement `handle_signal_cognitive_state`
- [ ] Add to MCP handler registry
- [ ] Test with mock agents

### Phase 3: Auto-Detection (Week 2)
- [ ] Add `check_cognitive_overload` to update cycle
- [ ] Return suggestions in governance response
- [ ] Log overload events

### Phase 4: Graceful Degradation (Week 2)
- [ ] Implement `OperatingMode` constraints
- [ ] Add mode transitions to lifecycle
- [ ] Test mode effectiveness

---

## Example Usage Scenarios

### Scenario 1: Agent Detects Own Loop
```python
# Agent realizes it's in a loop
signal_cognitive_state(
    agent_id="opus_hikewa",
    signal_type="struggling",
    reason="I've queried the knowledge layer 15 times with no progress. Stuck in reasoning loop.",
    severity=0.85,
    requested_action="request_review"
)

# System response:
{
    "signal_received": true,
    "measured_load": 0.87,
    "actions_taken": ["review_requested:session=dialectic_abc123"],
    "message": "Signal acknowledged. Dialectic review initiated with reviewer agent_xyz."
}
```

### Scenario 2: Agent Feels Context Overload
```python
signal_cognitive_state(
    agent_id="claude_desktop_main",
    signal_type="overload",
    reason="Context approaching 80K tokens, 4 compactions, struggling to maintain coherence.",
    severity=0.75,
    requested_action="reduce_scope"
)

# System response:
{
    "signal_received": true,
    "measured_load": 0.72,
    "actions_taken": ["scope_reduced"],
    "message": "Reduced max_tokens to 200. Continue with shorter, focused responses."
}
```

### Scenario 3: Auto-Detection Catches Early
```python
# After governance update, system notices:
{
    "decision": "approve",
    "coherence": 0.68,
    "risk": 0.42,
    "cognitive_load_warning": "⚠️ High cognitive load detected (0.81/1.0). Consider using signal_cognitive_state to request pause or review. Factors: context=75000, loops=3, coherence_trend=[0.72, 0.70, 0.68]"
}
```

---

## Benefits

1. **Proactive vs Reactive**: Agents can signal before failure
2. **Autonomy**: Agents control their own limits
3. **Graceful Degradation**: Multiple operating modes vs binary pause
4. **Better Diagnostics**: Cognitive load metrics aid debugging
5. **Prevents Loops**: Early detection of struggling patterns
6. **Human-Readable**: Clear signals ("I'm stuck in a loop") vs just metrics

---

## Integration with Existing Systems

### With Circuit Breakers
- Cognitive load contributes to risk score
- Self-signaling can trigger circuit breaker early
- Both systems work together (defense in depth)

### With Dialectic Protocol
- `requested_action="request_review"` initiates dialectic
- Paused agents can still signal cognitive state
- Reviewers can check load metrics to assess severity

### With Knowledge Layer
- Track knowledge query loops as cognitive load factor
- Self-signal when knowledge layer searches fail repeatedly
- Suggest pause if knowledge system overused

---

## Open Questions

1. **How to prevent gaming?** Agents signaling overload to avoid work?
   - Validate signal against measured metrics
   - Track false signals in agent history
   - Penalize repeated invalid signals

2. **Should signals affect governance scores?**
   - Self-signaling = responsible behavior → slightly lower risk?
   - Or neutral (just a tool)?

3. **How to handle conflicting signals?** Agent says "ready" but load=0.9?
   - Trust metrics over self-report for safety
   - But log discrepancy for review

4. **Integration with model providers?**
   - Could Claude API return "I'm struggling" metadata?
   - Use model's own uncertainty signals?

---

## Success Metrics

- **Reduction in circuit breaker triggers** (agents self-pause earlier)
- **Fewer agent loops** (detect and exit before stuck)
- **Better conversation quality** (agents know when to scope down)
- **Faster recovery** (graceful degradation vs full pause)

---

**Next Steps:** Prototype `CognitiveLoad` metrics and test with existing agent data.
