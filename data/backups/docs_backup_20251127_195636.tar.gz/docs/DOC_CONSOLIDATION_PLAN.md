# Documentation Consolidation Plan

**Problem:** 147 markdown files (42,599 lines) causing navigation and maintenance burden

**Created:** 2025-11-27 by Alva_Noto_Claude_CLI

---

## Current State Analysis

### By Directory
- **archive/** - 56 files (already archived, safe to compress)
- **analysis/** - 27 files (many could move to knowledge layer)
- **guides/** - 12 files (keep essential ones)
- **reference/** - 8 files (keep essential ones)
- **proposals/** - 4 files (evaluate: implement or archive)
- **architecture/** - 1 file (keep)
- **integration/** - 1 file (keep or merge)

### Root Level (docs/)
- 38+ standalone markdown files
- Many are session reports, incident logs, quick notes
- Good candidates for knowledge layer migration

---

## Proposed Solution: 3-Tier Documentation Strategy

### Tier 1: Essential Living Docs (Keep as Markdown)
**Keep only docs that require narrative structure or frequent reference:**

1. **README.md** (root) - Entry point
2. **ONBOARDING.md** - User onboarding
3. **SYSTEM_SUMMARY.md** - Current state snapshot
4. **USAGE_GUIDE.md** - How to use the system
5. **ARCHITECTURE.md** - System architecture
6. **QUICK_REFERENCE.md** - Quick lookups
7. **guides/TROUBLESHOOTING.md** - Common issues
8. **reference/AI_ASSISTANT_GUIDE.md** - AI agent guide
9. **authentication-guide.md** - Security guide
10. **CHANGELOG.md** - Version history

**Total: ~10-12 files** - everything else moves

### Tier 2: Knowledge Layer (Migrate)
**Convert to structured knowledge entries:**

- All analysis/* reports → `discovery` entries with `discovery_type="analysis"`
- Bug fixes → `discovery` with `discovery_type="bug_found"`
- Incidents → `discovery` with `discovery_type="incident"` + `severity` tag
- Patterns → `pattern` entries
- Lessons learned → `lesson` entries
- Session notes → agent metadata `notes` field

**Target: 100+ knowledge entries** replacing ~120 markdown files

### Tier 3: Archive Compression (One-time)
**Compress historical archives:**

```bash
# Create single compressed archive
tar -czf docs_archive_2025-11-27.tar.gz docs/archive/
# Store in data/archives/
# Delete docs/archive/ directory
```

**Result: 56 files → 1 compressed archive**

---

## Implementation Steps

### Phase 1: Create Migration Script (1 hour)

```python
# scripts/migrate_docs_to_knowledge.py

import json
from pathlib import Path
from src.knowledge_layer import store_knowledge

def migrate_markdown_to_knowledge(md_file, agent_id="system_migration"):
    """
    Parse markdown file and convert to knowledge entries.

    Heuristics:
    - Filename contains "FIX" → discovery_type="bug_found"
    - Filename contains "INCIDENT" → discovery_type="incident"
    - Filename contains "ANALYSIS" → discovery_type="analysis"
    - In analysis/ → discovery_type="analysis"
    - In proposals/ → knowledge_type="pattern" or archive
    """
    pass  # Implementation details
```

### Phase 2: Dry Run (30 minutes)
- Run migration script with `--dry-run` flag
- Review what would be migrated
- Verify knowledge entries make sense

### Phase 3: Execute Migration (1 hour)
- Migrate non-essential docs to knowledge layer
- Move remaining to data/doc_backups/ (don't delete yet)
- Verify knowledge layer has all content

### Phase 4: Clean Up (30 minutes)
- Keep only Tier 1 essential docs
- Update navigation in README
- Create DOC_MAP.md for quick reference

---

## After Consolidation

### New docs/ Structure
```
docs/
├── README.md                  # Navigation hub
├── DOC_MAP.md                 # Quick reference map
├── guides/                    # 3-4 essential guides
│   ├── TROUBLESHOOTING.md
│   ├── PARAMETER_TUNING.md
│   └── KNOWLEDGE_LAYER_USAGE.md
├── reference/                 # 2-3 reference docs
│   ├── AI_ASSISTANT_GUIDE.md
│   └── MCP_TOOLS_REFERENCE.md
└── architecture/              # 1 architecture doc
    └── LAYER_ARCHITECTURE.md
```

**Total: ~15 markdown files** (down from 147)

### Navigation
All content still accessible via:
1. **README sections** - for essential docs
2. **DOC_MAP.md** - quick reference for all docs
3. **search_knowledge()** - for migrated content
4. **list_knowledge()** - browse all entries

---

## Benefits

**Before:**
- 147 markdown files scattered across 7 directories
- Hard to find relevant information
- Duplication between docs
- Maintenance burden (many outdated)

**After:**
- ~15 essential markdown docs (well-organized)
- 100+ structured knowledge entries (queryable)
- Clear navigation via README + DOC_MAP
- Easier maintenance (less to update)

---

## Alternative: Documentation Database

If knowledge layer isn't sufficient, consider:

**SQLite documentation database:**
```python
# Structured queries
SELECT * FROM docs WHERE category='troubleshooting' AND updated > '2025-11-01'

# Full-text search
SELECT * FROM docs WHERE content MATCH 'coherence threshold'

# Tag-based navigation
SELECT * FROM docs JOIN tags ON docs.id=tags.doc_id WHERE tags.name='security'
```

But knowledge layer should be sufficient for most use cases.

---

## Risk Mitigation

**Before deleting anything:**
1. Create full backup: `tar -czf docs_full_backup_2025-11-27.tar.gz docs/`
2. Store in `data/backups/`
3. Keep for 90 days
4. Document migration mapping (old file → knowledge entry ID)

**Rollback plan:**
If migration fails, restore from backup:
```bash
tar -xzf data/backups/docs_full_backup_2025-11-27.tar.gz
```

---

## Decision

**Recommend: Proceed with Tier 1-2-3 strategy**

- Low risk (full backup before migration)
- High value (90% reduction in files)
- Preserves all content (just reorganized)
- Aligns with existing DOCUMENTATION_GUIDELINES.md

---

## Next Steps

1. Review this plan
2. Run `scripts/migrate_docs_to_knowledge.py --dry-run`
3. Review migration output
4. Execute if acceptable
5. Update README with new navigation

---

**Estimated effort:** 3-4 hours total
**Estimated benefit:** Ongoing reduction in cognitive load and maintenance burden
