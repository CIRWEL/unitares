# Documentation Sync Guide

**Date:** 2025-11-26  
**Purpose:** Ensure code changes are immediately reflected in documentation  
**Status:** Active

---

## Problem

Code changes often happen without corresponding documentation updates, leading to:
- Outdated examples
- Incorrect usage instructions
- Confusion for future agents/developers
- Knowledge drift

---

## Solution: Sync-on-Change Pattern

**Rule:** When you change code, update docs in the same change set.

---

## Documentation Locations

### Code Changes → Doc Updates

| Code Change | Documentation to Update |
|-------------|------------------------|
| New tool/handler | `src/mcp_server_std.py` (tool definition), `docs/guides/` (usage guide) |
| Architecture change | `docs/analysis/`, `ARCHITECTURE.md`, `docs/reference/HOUSEKEEPING.md` |
| API change | `docs/reference/`, `docs/guides/` |
| Bug fix | `docs/analysis/` (if documented), `docs/reference/FIXES_AND_INCIDENTS.md` |
| New feature | `docs/proposals/` (if proposed), `docs/guides/` (usage), `README.md` (if major) |

---

## Sync Checklist

When making code changes, check:

- [ ] **Tool definitions** (`src/mcp_server_std.py`) - Are descriptions accurate?
- [ ] **Handler registry** (`src/mcp_handlers/__init__.py`) - Are tools registered?
- [ ] **Usage guides** (`docs/guides/`) - Do examples still work?
- [ ] **Architecture docs** (`ARCHITECTURE.md`, `docs/analysis/`) - Is structure documented?
- [ ] **Housekeeping** (`docs/reference/HOUSEKEEPING.md`) - Are file statuses current?
- [ ] **Knowledge base** - Store discoveries via `store_knowledge` tool

---

## Examples

### Example 1: Adding New Tool

**Code Change:**
```python
# src/mcp_handlers/lifecycle.py
async def handle_new_tool(arguments):
    ...
```

**Required Doc Updates:**
1. ✅ Register in `src/mcp_handlers/__init__.py`
2. ✅ Add tool definition to `src/mcp_server_std.py` (`list_tools()`)
3. ✅ Create/update usage guide in `docs/guides/`
4. ✅ Update `docs/reference/HOUSEKEEPING.md` if file status changes
5. ✅ Store discovery via `store_knowledge` if it's a pattern/insight

### Example 2: Removing/Archiving File

**Code Change:**
```python
# Archive or delete file
```

**Required Doc Updates:**
1. ✅ Update `docs/reference/HOUSEKEEPING.md` - Mark as archived/deleted
2. ✅ Update any docs that reference it
3. ✅ Create analysis doc explaining why (if significant)
4. ✅ Store discovery about removal reason

### Example 3: Architecture Change

**Code Change:**
```python
# Change server architecture
```

**Required Doc Updates:**
1. ✅ Update `ARCHITECTURE.md` if major change
2. ✅ Create analysis doc in `docs/analysis/` explaining change
3. ✅ Update `docs/reference/HOUSEKEEPING.md` file status
4. ✅ Update any guides that reference old architecture

---

## Knowledge Storage

**Use `store_knowledge` tool for:**
- Discoveries (bugs, insights, improvements)
- Patterns (reusable solutions)
- Lessons learned
- Questions for future investigation

**Don't create markdown files for:**
- Small discoveries (< 1000 words) - use `store_knowledge` instead
- Quick notes - use `store_knowledge` instead

**Do create markdown files for:**
- Comprehensive reports (> 1000 words)
- Detailed analysis documents
- Proposals with full context

---

## Verification Steps

After making changes:

1. **Grep for references:**
   ```bash
   grep -r "old_name\|old_pattern" docs/ src/
   ```

2. **Check related files:**
   - If changing handler → check registry
   - If changing tool → check tool definitions
   - If changing architecture → check all architecture docs

3. **Test examples:**
   - Do code examples in docs still work?
   - Are paths correct?
   - Are tool names accurate?

4. **Update housekeeping:**
   - File statuses current?
   - Active/legacy files marked correctly?

---

## Common Mistakes to Avoid

❌ **Don't:**
- Change code without updating docs
- Defer doc updates "for later"
- Assume docs are someone else's job
- Update docs in separate PR (do it together)

✅ **Do:**
- Update docs in same change set as code
- Verify examples still work
- Check all related documentation
- Store discoveries immediately

---

## Tools for Doc Sync

### Find References
```bash
# Find all references to a pattern
grep -r "pattern" docs/ src/

# Find files that import/use something
grep -r "from.*module\|import.*module" src/
```

### Verify Tool Registration
```python
# Check if tool is registered
grep "tool_name" src/mcp_handlers/__init__.py
grep "tool_name" src/mcp_server_std.py
```

### Check Documentation
```bash
# List all docs that might need updating
find docs/ -name "*.md" -type f
```

---

## Quick Reference

**When you change:**
- **Handler** → Update registry + tool definition + usage guide
- **Tool** → Update tool definition + usage guide + examples
- **File** → Update HOUSEKEEPING.md + any references
- **Architecture** → Update ARCHITECTURE.md + analysis docs
- **Pattern** → Store via `store_knowledge` tool

**Always:**
- Update docs in same change set
- Verify examples work
- Check related files
- Store discoveries

---

## Related Documentation

- [Housekeeping Notes](../reference/HOUSEKEEPING.md)
- [Knowledge Storage Guide](../reference/KNOWLEDGE_STORAGE.md)
- [MCP Server Consolidation](../analysis/MCP_SERVER_CONSOLIDATION.md)

---

**Remember:** Documentation is code. Keep it in sync.

