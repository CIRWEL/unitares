# MCP Server Consolidation Investigation

**Date:** 2025-11-26  
**Investigator:** composer_cursor_assistant_20251126  
**Status:** Analysis Complete

---

## Current Architecture

### Active Server (1)
- **`src/mcp_server_std.py`** - Production MCP server
  - ✅ Used in configs (Cursor & Claude Desktop)
  - ✅ All handlers import it directly
  - ✅ Full MCP SDK implementation
  - ✅ 43 tools registered
  - ✅ Handler registry pattern

### Legacy/Support Files (2)

1. **`src/mcp_server_entry.py`** - Legacy entry point
   - ❌ **NOT imported anywhere** (only docs mention it)
   - ❌ **NOT used in configs**
   - Wraps old `GovernanceMCPServer` class
   - Kept for "backward compatibility" but not actively used

2. **`src/mcp_server.py`** - JSON-RPC wrapper class
   - ✅ **IS used** by `scripts/claude_code_bridge.py`
   - Provides `GovernanceMCPServer.handle_request()` method
   - Simple JSON-RPC interface for bridges
   - Only 4 tools (vs 43 in std)

---

## Investigation Results

### `mcp_server_entry.py` Usage

**Code References:**
- ❌ No Python imports found
- ❌ Not referenced in any config files
- ❌ Not used by any scripts
- ✅ Only mentioned in documentation (HOUSEKEEPING.md, SECURITY_AUDIT.md)

**Conclusion:** Safe to remove or archive.

### `mcp_server.py` Usage

**Code References:**
- ✅ Used by `scripts/claude_code_bridge.py` (line 19, 70, 249, 293, 304)
- ✅ Used by `demos/demo_complete_system.py` (line 23)
- ✅ Provides `handle_request()` method for JSON-RPC interface
- ✅ Only implements 4 tools:
  - `process_agent_update`
  - `get_governance_metrics`
  - `get_system_history`
  - `reset_monitor`

**Conclusion:** Still needed for bridge AND demo compatibility. Both are active (demo updated Nov 18). Could be migrated in future.

---

## Recommendations

### Option 1: Remove `mcp_server_entry.py` (RECOMMENDED)

**Action:** Archive or delete `mcp_server_entry.py`

**Rationale:**
- Not imported anywhere
- Not used in configs
- Superseded by `mcp_server_std.py`
- Only mentioned in docs

**Risk:** Low - no code dependencies

**Steps:**
1. Move to `docs/archive/` or delete
2. Update HOUSEKEEPING.md to reflect removal
3. Update any docs that reference it

### Option 2: Keep `mcp_server.py` for Bridges & Demo (RECOMMENDED)

**Action:** Keep `mcp_server.py` class for bridge and demo compatibility

**Rationale:**
- `claude_code_bridge.py` depends on it
- `demos/demo_complete_system.py` depends on it (active demo, updated Nov 18)
- Provides simple JSON-RPC interface
- Migration would require bridge AND demo refactoring
- Low maintenance burden (only 4 tools)

**Future Migration Path:**
- Could migrate bridge AND demo to use handler registry directly
- Or create adapter in `mcp_server_std.py` for JSON-RPC compatibility
- Would give both bridge and demo access to all 43 tools (not just 4)

### Option 3: Consolidate Everything (FUTURE)

**Action:** Migrate bridge to use `mcp_server_std.py` handlers directly

**Rationale:**
- Single codebase
- All tools available to bridges
- Consistent architecture

**Effort:** Medium - requires bridge refactoring

**Steps:**
1. Update `claude_code_bridge.py` to use handler registry
2. Update `demos/demo_complete_system.py` to use handler registry
3. Remove `mcp_server.py` dependency
4. Test bridge and demo functionality

---

## Final Recommendation

**Immediate Action:**
1. ✅ **Remove `mcp_server_entry.py`** - Not used, safe to delete
2. ✅ **Keep `mcp_server.py`** - Still needed for bridges

**Future Consideration:**
- Migrate bridge to use `mcp_server_std.py` handlers directly
- This would allow bridges to access all 43 tools (not just 4)

---

## Summary

**Current State:**
- 1 active server: `mcp_server_std.py` ✅
- 1 legacy file: `mcp_server_entry.py` ❌ (can remove)
- 1 support class: `mcp_server.py` ✅ (keep for bridges)

**Answer:** You have **ONE active server** (`mcp_server_std.py`). The others are legacy/support files. Architecture is fine, but `mcp_server_entry.py` can be safely removed.

---

## Files to Update

1. Delete or archive: `src/mcp_server_entry.py`
2. Update: `docs/reference/HOUSEKEEPING.md` (remove entry)
3. Update: `docs/SECURITY_AUDIT.md` (remove reference)

---

## Related Knowledge

- Stored in governance system: `composer_cursor_assistant_20251126` discovery
- Tags: `architecture`, `cleanup`, `mcp-server`

