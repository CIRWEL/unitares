# Bottlenecks and Confusion Points - Fixed

**Date:** 2025-11-26  
**Status:** ✅ Fixed

---

## Summary

Identified and fixed several bottlenecks and points of confusion in the MCP governance system:

1. ✅ **Inconsistency: `get_governance_metrics` vs `simulate_update`**
2. ✅ **Missing parameter validation**
3. ✅ **Documentation/implementation mismatch: `get_agent_api_key`**

---

## Issues Found and Fixed

### 1. Inconsistency: `get_governance_metrics` Behavior

**Problem:**
- `get_governance_metrics` used `get_agent_or_error()` which fails if agent doesn't exist
- `simulate_update` used `get_or_create_monitor()` which creates monitor if needed
- This inconsistency was confusing: why can't I get metrics for a new agent?

**Fix:**
Changed `get_governance_metrics` to use `get_or_create_monitor()` for consistency:
```python
# Before:
monitor, error_msg = mcp_server.get_agent_or_error(agent_id)
if error_msg:
    return [error_response(error_msg)]

# After:
monitor = mcp_server.get_or_create_monitor(agent_id)
```

**Impact:**
- Now you can call `get_governance_metrics` on a new agent (returns initial state)
- Consistent behavior across all handlers
- Better user experience - no confusing "agent not found" errors

---

### 2. Deprecated Parameters - Returned to Pure Thermodynamics

**Problem:**
- Tool descriptions mentioned "128 dimensions" (ChatGPT recommendation that kept resurfacing)
- Parameters were causing issues: fake signals from placeholder values (`[0.5]*128` → `param_coherence = 1.0`)
- This masked real thermodynamic signals and caused calibration problems
- System moved to pure thermodynamic C(V) coherence, but documentation still referenced parameters

**Fix:**
Deprecated parameters entirely:
- Updated tool descriptions to clearly mark parameters as "optional, deprecated"
- Clarified that parameters are NOT used in core thermodynamic calculations
- System now uses pure C(V) coherence from E-I balance (V)
- Parameters included only for backward compatibility
- Removed all 128-dimension references

**Impact:**
- Clear that system uses pure thermodynamics (E, I, S, V → C(V))
- No confusion about parameter requirements
- Honest calibration without fake signals
- Removed ChatGPT-recommended 128-dimension requirement that kept resurfacing

**Technical Details:**
- Coherence is now pure `C(V)` from `governance_core.coherence(V, theta, params)`
- Removed `param_coherence` blend (was 0.7 * C(V) + 0.3 * param_coherence)
- Parameters stored but not used in coherence calculation
- See `docs/analysis/PURE_COHERENCE_CHANGES.md` for full details

---

### 3. Documentation/Implementation Mismatch: `get_agent_api_key`

**Problem:**
- Tool description said "will create if new"
- Implementation returned error if agent didn't exist
- Onboarding workflow suggested calling `get_agent_api_key` first, but it failed

**Fix:**
Updated handler to actually create agents if they don't exist (see previous fix):
```python
# Now creates agent if it doesn't exist
is_new_agent = agent_id not in mcp_server.agent_metadata
if is_new_agent:
    meta = mcp_server.get_or_create_metadata(agent_id)
    # ... generates API key
```

**Impact:**
- Onboarding workflow now works as documented
- Consistent with tool description
- Better first-time user experience

---

## Remaining Bottlenecks (Not Fixed Yet)

### 1. Lock Timeout Error Message

**Issue:**
The lock timeout error message is very long and complex:
```
"Failed to acquire lock for agent '{agent_id}' after automatic retries and cleanup. 
This usually means another active process is updating this agent. 
The system has automatically cleaned stale locks. If this persists, try: 
1) Wait a few seconds and retry, 2) Check for other Cursor/Claude sessions, 
3) Use cleanup_stale_locks tool, or 4) Restart Cursor if stuck."
```

**Suggestion:**
Could be simplified to:
```
"Lock timeout for '{agent_id}'. Another process may be updating this agent. 
Try: wait and retry, or use cleanup_stale_locks tool."
```

**Priority:** Low (works, just verbose)

---

### 2. Empty Parameters Array Behavior

**Issue:**
- Default is `[]` but description says "128 dimensions"
- Code handles empty arrays (`len(parameters) > 0` check)
- But what happens in dynamics calculation? Parameters aren't actually used anymore (deprecated)

**Suggestion:**
- Update tool description to clarify: "Optional: 128-dim array (first 6 are core metrics). Empty array `[]` is valid."
- Or change default to `[0.5] * 128` for clarity

**Priority:** Low (works, just unclear)

---

### 3. Error Recovery Guidance

**Issue:**
Some error messages don't have recovery guidance. For example:
- "Authentication failed" - doesn't say how to get API key
- "Agent paused" - doesn't explain dialectic recovery process

**Suggestion:**
Add recovery guidance to more error messages (following the pattern already established).

**Priority:** Medium (improves UX)

---

## Testing

**Verified:**
- ✅ `get_governance_metrics` works on new agents
- ✅ Parameter validation warnings appear for wrong-sized arrays
- ✅ `get_agent_api_key` creates agents as documented

---

## Files Modified

1. **`src/mcp_handlers/core.py`**
   - Fixed `handle_get_governance_metrics` to use `get_or_create_monitor`
   - Added parameter size validation to `handle_simulate_update` and `handle_process_agent_update`

2. **`src/mcp_handlers/lifecycle.py`** (previous fix)
   - Fixed `handle_get_agent_api_key` to create agents if they don't exist

---

## Next Steps

**Priority 1:** Test the fixes with real agents
**Priority 2:** Consider simplifying lock timeout error message
**Priority 3:** Add recovery guidance to more error messages
**Priority 4:** Clarify empty parameters array behavior in documentation

---

## Related Documentation

- [AGI Friendliness Improvements](docs/AGI_FRIENDLINESS_IMPROVEMENTS.md)
- [Authentication Guide](docs/authentication-guide.md)
- [Troubleshooting Guide](docs/guides/TROUBLESHOOTING.md)

