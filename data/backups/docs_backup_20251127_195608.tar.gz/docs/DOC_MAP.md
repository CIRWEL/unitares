# Documentation Map

**Quick navigation for all documentation in the governance system**

**Last Updated:** 2025-11-27

---

## 🚀 Start Here

| Doc | Purpose | Audience |
|-----|---------|----------|
| [README.md](../README.md) | System overview, quick start | Everyone |
| [ONBOARDING.md](../ONBOARDING.md) | Complete onboarding guide | New users |
| [SYSTEM_SUMMARY.md](../SYSTEM_SUMMARY.md) | Current state snapshot | All |

---

## 📘 Core Documentation

### User Guides
- [USAGE_GUIDE.md](../USAGE_GUIDE.md) - How to use the system
- [guides/TROUBLESHOOTING.md](guides/TROUBLESHOOTING.md) - Common issues and fixes
- [guides/PARAMETER_TUNING.md](guides/PARAMETER_TUNING.md) - Tuning governance parameters
- [guides/KNOWLEDGE_LAYER_USAGE.md](guides/KNOWLEDGE_LAYER_USAGE.md) - Using knowledge layer

### Reference
- [QUICK_REFERENCE.md](QUICK_REFERENCE.md) - Quick lookups
- [reference/AI_ASSISTANT_GUIDE.md](reference/AI_ASSISTANT_GUIDE.md) - Guide for AI agents
- [reference/MCP_TOOLS_REFERENCE.md](reference/MCP_TOOLS_REFERENCE.md) - All 44 MCP tools
- [authentication-guide.md](authentication-guide.md) - Security and API keys

### Architecture
- [ARCHITECTURE.md](../ARCHITECTURE.md) - System architecture overview
- [architecture/LAYER_ARCHITECTURE.md](architecture/LAYER_ARCHITECTURE.md) - Detailed layer design

---

## 🔍 Finding Information

### For Specific Topics

**Topic** → **Where to Look**

- **Getting started** → [ONBOARDING.md](../ONBOARDING.md)
- **MCP tools** → [reference/MCP_TOOLS_REFERENCE.md](reference/MCP_TOOLS_REFERENCE.md)
- **Troubleshooting** → [guides/TROUBLESHOOTING.md](guides/TROUBLESHOOTING.md)
- **Architecture** → [ARCHITECTURE.md](../ARCHITECTURE.md)
- **Configuration** → [USAGE_GUIDE.md](../USAGE_GUIDE.md) + `get_thresholds` tool
- **Security/Auth** → [authentication-guide.md](authentication-guide.md)
- **AI agent usage** → [reference/AI_ASSISTANT_GUIDE.md](reference/AI_ASSISTANT_GUIDE.md)
- **Knowledge layer** → [guides/KNOWLEDGE_LAYER_USAGE.md](guides/KNOWLEDGE_LAYER_USAGE.md)
- **Past incidents** → Use `search_knowledge(tags=["incident"])`
- **Bug fixes** → Use `search_knowledge(knowledge_type="discovery", discovery_type="bug_found")`
- **System patterns** → Use `search_knowledge(knowledge_type="pattern")`
- **Lessons learned** → Use `search_knowledge(knowledge_type="lesson")`

### Search Methods

**1. MCP Knowledge Layer (Recommended)**
```python
# Search by tags
search_knowledge(tags=["security", "authentication"])

# Search by type
search_knowledge(knowledge_type="discovery", discovery_type="incident")

# Text search
search_knowledge(query="coherence threshold")

# List all
list_knowledge()
```

**2. File Search**
```bash
# Search markdown files
grep -r "coherence" docs/

# Find specific doc
find docs/ -name "*THRESHOLD*"
```

**3. Git History**
```bash
# Find when something changed
git log --all --grep="coherence"

# Find who changed a file
git blame docs/QUICK_REFERENCE.md
```

---

## 📊 Documentation by Category

### Essential (Keep Updated)
- Core docs (README, ONBOARDING, SYSTEM_SUMMARY)
- User guides (USAGE_GUIDE, TROUBLESHOOTING)
- Reference docs (AI_ASSISTANT_GUIDE, MCP_TOOLS_REFERENCE)

### Historical (Knowledge Layer)
- Incident reports → `search_knowledge(tags=["incident"])`
- Bug fixes → `search_knowledge(discovery_type="bug_found")`
- Analysis reports → `search_knowledge(tags=["analysis"])`
- Lessons learned → `search_knowledge(knowledge_type="lesson")`

### Archived (Compressed)
- Old versions → `data/backups/docs_archive_*.tar.gz`
- Deprecated docs → Check git history

---

## 🎯 Quick Tasks

| I want to... | Use this... |
|-------------|-------------|
| Learn the system | [ONBOARDING.md](../ONBOARDING.md) |
| Use MCP tools | [reference/MCP_TOOLS_REFERENCE.md](reference/MCP_TOOLS_REFERENCE.md) |
| Fix a problem | [guides/TROUBLESHOOTING.md](guides/TROUBLESHOOTING.md) |
| Tune parameters | [guides/PARAMETER_TUNING.md](guides/PARAMETER_TUNING.md) |
| Store a discovery | `store_knowledge()` MCP tool |
| Find past incidents | `search_knowledge(tags=["incident"])` |
| Understand architecture | [ARCHITECTURE.md](../ARCHITECTURE.md) |
| Quick reference | [QUICK_REFERENCE.md](QUICK_REFERENCE.md) |

---

## 📝 Contributing Documentation

**Guidelines:**

1. **Use knowledge layer for:**
   - Discoveries, insights, patterns
   - Bug reports, incident logs
   - Lessons learned

2. **Use markdown ONLY for:**
   - Comprehensive guides (1000+ words)
   - Reference documentation
   - Living documents that need updates

3. **See:** [DOCUMENTATION_GUIDELINES.md](DOCUMENTATION_GUIDELINES.md)

---

## 🗺️ Navigation Tips

### For Humans
- Start with [ONBOARDING.md](../ONBOARDING.md)
- Use this DOC_MAP for quick lookups
- Search knowledge layer for specific topics

### For AI Agents
- Read [reference/AI_ASSISTANT_GUIDE.md](reference/AI_ASSISTANT_GUIDE.md) first
- Use `list_tools()` to discover capabilities
- Use `search_knowledge()` for past discoveries
- Follow [DOCUMENTATION_GUIDELINES.md](DOCUMENTATION_GUIDELINES.md)

---

## 📦 Document Lifecycle

```
New Information
      ↓
Is it a comprehensive guide (1000+ words)?
      ↓ NO
Use store_knowledge()
      ↓
Knowledge Layer (queryable, structured)
      ↓
If superseded → remains in knowledge layer with tags
```

```
New Information
      ↓
Is it a comprehensive guide (1000+ words)?
      ↓ YES
Create markdown in appropriate directory
      ↓
When outdated → migrate to knowledge layer or archive
```

---

## 🔗 External Resources

- [MCP Protocol Spec](https://modelcontextprotocol.io/)
- [UNITARES Framework](https://github.com/unitares) (if published)
- Project GitHub Issues (if applicable)

---

**Remember:** When lost, start with [README.md](../README.md) or [ONBOARDING.md](../ONBOARDING.md)
