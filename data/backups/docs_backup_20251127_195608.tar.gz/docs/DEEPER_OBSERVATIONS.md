# Deeper Observations & Remaining Issues

**Date:** November 26, 2025  
**Status:** Non-blocking observations for future improvement

---

## 🔍 Issues Found

### 1. **Hardcoded Paths in Onboarding Scripts** ⚠️

**Location:** `scripts/onboard_agent.py`, `scripts/discover_knowledge.py`

**Problem:**
```python
GOVERNANCE_PATH = Path.home() / "projects" / "governance-mcp-v1"
```

**Impact:**
- Scripts will fail if project is cloned to a different location
- Not portable across different user setups
- Breaks if project is moved or renamed

**Current Workaround:**
- Users must have project at `~/projects/governance-mcp-v1`
- Or manually edit the script

**Recommendation:**
```python
# Better approach - detect from script location
GOVERNANCE_PATH = Path(__file__).parent.parent
# Or use environment variable
GOVERNANCE_PATH = Path(os.getenv('GOVERNANCE_MCP_PATH', Path(__file__).parent.parent))
```

**Priority:** Medium (works for current setup, but brittle)

---

### 2. **Onboarding Script Silent Failures** ⚠️

**Location:** `scripts/onboard_agent.py:127-137`

**Problem:**
```python
try:
    result = process_update_authenticated(...)
    print(f"✓ First log created (ρ={metrics.get('coherence', 0):.3f})")
except Exception as e:
    # Don't fail onboarding if logging fails
    print(f"  (note: first log skipped - {e})", file=sys.stderr)
```

**Impact:**
- First governance log creation can fail silently
- Error message goes to stderr (might be missed)
- Onboarding appears successful even if logging failed
- No clear indication of what went wrong

**Recommendation:**
- Make error more visible (print to stdout with ⚠️)
- Provide recovery steps in error message
- Or make first log optional with clear messaging

**Priority:** Low (non-critical, but UX issue)

---

### 3. **Dialectic Protocol Metadata Bug Workaround** 🐛

**Location:** `src/mcp_handlers/dialectic.py:551` (mentioned in QUICK_NOTES.md)

**Problem:**
- Metadata sometimes contains strings instead of `AgentMetadata` objects
- Current fix: Workaround that skips invalid entries
- Root cause not investigated/fixed

**Current Code:**
```python
if isinstance(agent_meta, str):
    # This is the bug - metadata contains strings instead of objects
    continue  # Skip invalid entries
```

**Impact:**
- Some agents might be skipped in dialectic reviewer selection
- Could cause "no reviewers available" errors
- Indicates potential serialization/deserialization issue

**Recommendation:**
- Investigate where strings come from (likely JSON loading)
- Fix root cause in metadata loading/saving
- Add type validation when loading metadata

**Priority:** Medium (has workaround, but should be fixed)

---

### 4. **Knowledge Layer Not Integrated** ⏳

**Status:** Documented as pending in `docs/analysis/INTEGRATION_STATUS.md`

**Current State:**
- Module exists (`src/knowledge_layer.py` - 338 lines)
- MCP tools exist (`store_knowledge`, `retrieve_knowledge`, etc.)
- But not integrated into governance flow
- No automatic discovery tracking during governance cycles

**Impact:**
- Knowledge layer is manual-only
- Agents must explicitly call `store_knowledge`
- No automatic pattern detection from governance decisions
- Missing opportunity for cross-agent learning

**Recommendation:**
- Integrate knowledge layer into `process_agent_update`
- Auto-log high-severity discoveries
- Auto-track patterns in governance decisions
- Or document as "manual-only feature" clearly

**Priority:** Low-Medium (useful but not critical)

---

### 5. **Threshold Terminology Could Be Clearer** 📝

**Location:** `docs/QUICK_NOTES.md` mentions this

**Problem:**
- Two different risk thresholds serve different purposes:
  - **Decision thresholds:** `RISK_REVISE_THRESHOLD = 0.50` (stricter)
  - **Health status thresholds:** `risk_degraded_max = 0.60` (more lenient)
- Rationale exists but not prominently documented
- Could confuse new users

**Recommendation:**
- Add clear documentation explaining the difference
- Create `docs/guides/THRESHOLDS.md` with examples
- Add inline comments in config explaining rationale

**Priority:** Low (documentation improvement)

---

### 6. **Dead Code Already Removed** ✅

**Status:** Good news!

**Observation:**
- `track_normalize.py` is mentioned as "dead code" in multiple docs
- But file doesn't actually exist (checked via glob search)
- This is actually correct - dead code was already cleaned up

**Recommendation:**
- Update critique docs to mark as "✅ Already removed"
- Remove references to non-existent dead code

**Priority:** Low (documentation cleanup)

---

## 📊 Summary

### Critical Issues
- None found

### Medium Priority
1. Hardcoded paths in onboarding scripts (portability)
2. Dialectic metadata bug workaround (should fix root cause)
3. Knowledge layer not integrated (missing opportunity)

### Low Priority
1. Onboarding script silent failures (UX)
2. Threshold terminology clarity (documentation)
3. Dead code references (documentation cleanup)

---

## 🎯 Recommended Actions

### Immediate (If Time Permits)
1. **Fix hardcoded paths** - Use `Path(__file__).parent.parent` pattern
2. **Investigate dialectic metadata bug** - Find root cause, fix properly
3. **Update dead code references** - Mark as already removed

### Short Term
4. **Improve onboarding error visibility** - Make failures more obvious
5. **Add threshold documentation** - Create clear guide explaining differences
6. **Document knowledge layer status** - Clarify it's manual-only for now

### Long Term
7. **Integrate knowledge layer** - Auto-track discoveries during governance cycles
8. **Add path detection** - Use environment variables or auto-detection

---

## ✅ What's Actually Good

1. **Dead code already cleaned up** - `track_normalize.py` doesn't exist ✅
2. **Core features integrated** - Confidence gating, audit logging, calibration all working ✅
3. **Documentation mostly accurate** - Recent fixes have been applied ✅
4. **Onboarding works** - Despite hardcoded paths, works for current setup ✅
5. **Error recovery good** - Most errors have recovery guidance ✅

---

**Bottom Line:** System is in good shape. These are polish items, not blockers. The hardcoded path issue is the most important to fix for portability.

