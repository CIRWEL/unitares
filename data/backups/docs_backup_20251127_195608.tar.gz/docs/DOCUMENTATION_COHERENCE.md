# Documentation Coherence Issues

**Date:** 2025-11-25  
**Issue:** Documentation incoherence between parent-level and workspace-level docs  
**Status:** ✅ Fixed

---

## Problem

There was documentation incoherence between:
1. **Parent-level** `/Users/cirwel/CLAUDE.md` (for Claude CLI)
2. **Workspace-level** `governance-mcp-v1/README.md` (for this project)
3. **System configs** `~/.cursor/mcp.json` (MCP server configuration)

### Issues Found

1. **Server Count Mismatch**
   - CLAUDE.md claimed: "4 active MCP servers"
   - Actual config: 3 servers (governance-monitor, GitHub, date-context)
   - Missing: Notion MCP (inactive)

2. **Missing File Reference**
   - CLAUDE.md referenced: `scripts/utils/date_utils.py`
   - File didn't exist: `/Users/cirwel/scripts/utils/date_utils.py`
   - Impact: Import errors for any code using date utilities

3. **Security Note**
   - GitHub token in `~/.cursor/mcp.json` (system config, outside workspace)
   - Cannot be fixed from workspace, but documented

---

## Fixes Applied

### ✅ 1. Updated Server Count
**File:** `/Users/cirwel/CLAUDE.md`  
**Change:** Updated from "4 active MCP servers" to "3 active MCP servers"  
**Note:** Added note that Notion MCP is currently inactive

### ✅ 2. Created Missing File
**File:** `/Users/cirwel/scripts/utils/date_utils.py`  
**Created:** Complete date utilities module with:
- `today_full()` - "November 15, 2025"
- `today_short()` - "2025-11-15"
- `today_compact()` - "20251115"
- `now_timestamp()` - "2025-11-15 12:34:56"
- `get_current_date(format)` - Custom formats

### ✅ 3. Updated Integration Note
**File:** `/Users/cirwel/CLAUDE.md`  
**Change:** Clarified that `date_utils.py` complements Date Context MCP

---

## Documentation Structure

### Parent-Level (`/Users/cirwel/`)
- `CLAUDE.md` - Workspace-wide guidance for Claude CLI
- `scripts/utils/date_utils.py` - Shared date utilities
- Used by: All Claude instances working in parent workspace

### Workspace-Level (`governance-mcp-v1/`)
- `README.md` - Project-specific documentation
- `docs/` - Project documentation
- Used by: This specific project

### System-Level (`~/.cursor/`)
- `mcp.json` - MCP server configuration
- Contains: GitHub token (user responsibility to secure)
- Used by: Cursor IDE

---

## Best Practices Going Forward

### 1. Keep Documentation Synchronized
- ✅ Update parent-level docs when workspace changes affect them
- ✅ Update workspace docs when project-specific changes occur
- ✅ Document which level each doc serves

### 2. File References
- ✅ Verify referenced files exist before documenting
- ✅ Create missing files or update references
- ✅ Use relative paths when possible

### 3. Security
- ✅ Never commit secrets to git
- ✅ Document system-level configs separately
- ✅ Provide guidance for securing external configs

---

## Verification

### ✅ Server Count
```bash
# Check actual MCP servers in config
cat ~/.cursor/mcp.json | jq '.mcpServers | keys'
# Should show: governance-monitor, GitHub, date-context (3 servers)
```

### ✅ Date Utils
```bash
# Verify file exists
ls -la /Users/cirwel/scripts/utils/date_utils.py
# Should exist and be executable

# Test import
python3 -c "from scripts.utils.date_utils import today_full; print(today_full())"
# Should print current date
```

### ✅ Documentation
- ✅ CLAUDE.md updated (3 servers)
- ✅ date_utils.py created
- ✅ Integration note clarified

---

## Related Files

- `/Users/cirwel/CLAUDE.md` - Parent-level workspace guide
- `/Users/cirwel/scripts/utils/date_utils.py` - Date utilities (created)
- `governance-mcp-v1/README.md` - Workspace-specific docs
- `docs/SECURITY_AUDIT.md` - Security audit (workspace-level)
- `docs/CRITIQUE_RESPONSE.md` - Response to critique

---

## Status

✅ **All Issues Fixed**

- Server count corrected (4 → 3)
- Missing file created (`date_utils.py`)
- Documentation synchronized
- Security note documented

**Next Steps:**
- ✅ **Automated Prevention System Created** (2025-11-25)
- Use `./scripts/doc_sync.sh` to automatically sync docs from config
- Run `./scripts/validate_documentation.py` to check for drift
- See parent-level docs for full documentation architecture guide

**Automated Tools Available:**
- `scripts/doc_sync.sh` - One-command sync and validation
- `scripts/generate_mcp_docs.py` - Auto-generate docs from config
- `scripts/validate_documentation.py` - Find drift between docs and reality

**Workflow:**
```bash
# After ANY config change
./scripts/doc_sync.sh

# Before committing docs
./scripts/doc_sync.sh --validate

# Weekly health check
./scripts/doc_sync.sh && cat docs/VALIDATION_REPORT.md
```

**Golden Rule:** Config changes → Regenerate docs → Validate → Commit together

