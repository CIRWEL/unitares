# Tool Call Timeout Fix

**Date:** 2025-11-25  
**Issue:** MCP tool calls timing out, agents getting "No result received from client-side tool execution"

---

## Problem

Agents calling MCP tools (like `detect_anomalies`, `get_telemetry_metrics`) were experiencing timeouts:
- Tool calls hang indefinitely
- No response returned to agent
- Agents stuck waiting for responses

**Root Cause:**
1. **Blocking file I/O** - Telemetry collector reading entire audit log synchronously
2. **No timeout protection** - Tool calls could hang forever
3. **Blocking operations in async handlers** - Pattern analysis doing synchronous file reads

---

## Solution

### 1. Added Timeout Wrapper

**File:** `src/mcp_handlers/__init__.py`

```python
# Wrap handler call with timeout (30 seconds)
result = await asyncio.wait_for(
    handler(arguments),
    timeout=timeout_seconds
)
```

**Benefits:**
- Prevents infinite hangs
- Returns clear timeout error message
- Allows agents to retry or use fallback

### 2. Made File I/O Non-Blocking

**File:** `src/mcp_handlers/admin.py` - `handle_get_telemetry_metrics`

```python
# Execute blocking operations in thread pool
skip_metrics, conf_dist, calibration_metrics, suspicious = await asyncio.gather(
    loop.run_in_executor(None, telemetry.get_skip_rate_metrics, agent_id, window_hours),
    loop.run_in_executor(None, telemetry.get_confidence_distribution, agent_id, window_hours),
    loop.run_in_executor(None, telemetry.get_calibration_metrics),
    loop.run_in_executor(None, telemetry.detect_suspicious_patterns, agent_id)
)
```

**Benefits:**
- File I/O doesn't block event loop
- Multiple operations run concurrently
- Better performance

### 3. Optimized File Reading

**File:** `src/telemetry.py` - `get_confidence_distribution`

**Changes:**
- Read last 1000 lines instead of entire file
- Process in reverse (newest first) for early exit
- Stop when hitting cutoff time (optimization)

**Benefits:**
- Faster for large audit logs
- Less memory usage
- Better performance

### 4. Made Anomaly Detection Non-Blocking

**File:** `src/mcp_handlers/observability.py` - `handle_detect_anomalies`

**Changes:**
- Process agents in batches (10 at a time)
- Use `run_in_executor` for blocking operations
- Limit to 50 agents max for performance
- Concurrent processing with error handling

**Benefits:**
- Doesn't block event loop
- Handles large agent lists gracefully
- Better error recovery

---

## Configuration

**Timeout:** 30 seconds (configurable via `timeout_seconds`)

**Batch Size:** 10 agents per batch (for anomaly detection)

**File Read Limit:** Last 1000 lines (for telemetry)

---

## Testing

**Before Fix:**
- Tool calls hang indefinitely
- Agents stuck waiting
- No error messages

**After Fix:**
- Tool calls complete within timeout
- Clear error messages on timeout
- Agents can retry or use fallback

---

## Future Improvements

1. **Configurable timeouts** - Per-tool timeout configuration
2. **Progressive timeouts** - Longer timeout for expensive operations
3. **Async file I/O** - Use `aiofiles` for true async file operations
4. **Caching** - Cache telemetry results to reduce file reads
5. **Streaming** - Stream large results instead of loading all at once

---

## Related Issues

- Observer effect: Probing agents can unblock stuck tool calls
- Lock cleanup: Automatic stale lock cleanup prevents some hangs
- Process cleanup: Zombie process cleanup prevents resource exhaustion

---

## Status

✅ **Fixed** - Tool calls now have timeout protection and non-blocking I/O

**Next Steps:**
- Monitor for timeout occurrences
- Adjust timeout values if needed
- Consider async file I/O library (`aiofiles`) for better performance

