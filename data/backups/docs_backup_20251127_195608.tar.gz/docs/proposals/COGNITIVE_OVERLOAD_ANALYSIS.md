# Cognitive Overload: What's Missing vs. What's Redundant

**Created:** November 26, 2025
**Question:** Do we need explicit cognitive load tracking, or does UNITARES already detect this?

---

## The Math Already Works ✅

### Case Study: opus_hikewa_governance_tightening_20251126

**What happened:**
- 11 governance updates
- Decisions: mostly revise/reject (struggling pattern)
- Circuit breaker triggered at update 11

**What UNITARES detected:**
```
Risk: 71.12% (threshold: 70%)
Coherence: 0.482 (threshold: 0.50)
→ Agent paused automatically
```

**Conclusion:** The thermodynamic metrics caught the degradation perfectly.

---

## What Each Metric Already Captures

| Metric | Natural Interpretation | Cognitive Overload Signal |
|--------|----------------------|---------------------------|
| **Coherence (ρ)** | System organization | Drops when agent confused/struggling |
| **Entropy (S)** | Information disorder | Rises with complexity burden |
| **Void (V)** | Stability anomalies | Spikes on weird/unstable behavior |
| **Energy (E)** | Computational effort | High = lots of processing |
| **Information (I)** | Data integrity | Drops = garbled thinking |
| **Risk** | Composite safety | 70% UNITARES + 30% traditional |
| **Loop Detection** | Pattern repetition | Direct loop catching |

**Key insight:** Cognitive overload manifests as:
- ↓ Coherence (disorganized thinking)
- ↑ Entropy (higher disorder)
- ↑ Risk (system detects danger)
- Repeated decisions (loops)

**All of these are already measured!**

---

## So What's Actually Missing?

Not the **detection** (math works), but the **interface** and **agency**:

### 1. Agent Self-Awareness (Interpretability)

**Current state:**
```json
{
  "coherence": 0.482,
  "risk": 0.711,
  "decision": "revise"
}
```

Agent sees numbers but may not understand:
- "What does coherence=0.48 mean for me?"
- "Why am I getting 'revise' repeatedly?"
- "Should I stop or keep going?"

**Missing:** Human-readable interpretation of metrics

### 2. Agent Agency (Proactive Control)

**Current state:**
- System detects overload → pauses agent (reactive)
- Agent has no say in the matter

**Missing:**
- Agent can't preemptively say "I'm struggling, let me pause"
- No graceful self-regulation before hitting thresholds
- Binary: work normally or get paused

### 3. Actionable Suggestions (Guidance)

**Current state:**
```json
{
  "decision": "revise",
  "coherence": 0.482
}
```

**Missing:** What should agent DO about it?
```json
{
  "decision": "revise",
  "coherence": 0.482,
  "suggestion": "Coherence declining (0.72→0.48). Consider: reduce scope, request review, or signal need for break."
}
```

### 4. Post-Pause Behavior (Your Actual Problem)

**What happened to your agent:**
1. Circuit breaker fired → paused ✅
2. Agent resumed somehow
3. Got stuck in knowledge layer loop ❌
4. Metadata said "waiting_input" but was actually looping ❌

**The issue:** Not the detection, but what happens AFTER pause.

---

## Minimal Additions (Non-Redundant)

### Option A: Interpretability Layer Only

Add human-readable interpretation to existing metrics:

```python
def interpret_governance_state(coherence, entropy, risk, decisions):
    """Convert metrics to actionable guidance"""

    if coherence < 0.5 and risk > 0.7:
        return {
            "state": "critical_overload",
            "interpretation": "Your coherence (0.48) is below healthy range (>0.70). System organization is degrading.",
            "suggestion": "Consider: signal need for review, reduce task scope, or pause temporarily.",
            "urgency": "high"
        }

    elif coherence < 0.7 and len([d for d in decisions[-5:] if d == 'revise']) >= 3:
        return {
            "state": "struggling",
            "interpretation": "Multiple 'revise' decisions suggest repeated attempts without progress.",
            "suggestion": "You may be in a loop. Consider changing approach or requesting peer review.",
            "urgency": "medium"
        }

    # ... more patterns
```

**Benefit:** Agent understands what metrics mean
**Cost:** Minimal (just translation layer)

### Option B: Self-Signaling Tool Only

Allow agent to proactively signal before hitting thresholds:

```python
# Agent notices loop before system does
signal_need_for_break(
    reason="I've queried knowledge layer 10 times without progress"
)
```

**Benefit:** Agent agency, proactive vs reactive
**Cost:** One new MCP tool, validation against metrics

### Option C: Post-Pause State Machine

Fix the actual problem: what happens after circuit breaker?

```python
class PostPauseState(Enum):
    PAUSED = "paused"                    # Waiting for review
    DIALECTIC_REVIEW = "in_review"       # Peer review active
    CONDITIONALLY_RESUMED = "resumed"    # Back but monitored
    WAITING_INPUT = "waiting_input"      # Truly done, waiting for user

# After circuit breaker:
if agent.status == "paused":
    # Don't allow arbitrary resumption
    # Require either:
    # 1. Dialectic review completion
    # 2. Explicit user approval
    # 3. Metrics return to healthy range
```

**Benefit:** Prevents pause → loop cycle
**Cost:** State machine for lifecycle

---

## Recommendation: Minimal Approach

### What to Add (Non-Redundant):

1. **Interpretability layer** (Option A)
   - Add `interpretation` and `suggestion` fields to governance response
   - No new metrics, just translate existing ones
   - Cost: ~50 lines of code

2. **Self-signaling tool** (Option B)
   - Single MCP tool: `signal_cognitive_state`
   - Validates against existing metrics (no gaming)
   - Cost: ~100 lines of code

3. **Post-pause state machine** (Option C)
   - Fix the actual bug: paused → resumed → looped
   - Enforce dialectic review or user approval after pause
   - Cost: ~150 lines of code

### What NOT to Add (Redundant):

❌ **CognitiveLoad dataclass** - coherence/entropy/risk already measure this
❌ **load_score computation** - risk score already does this
❌ **Separate tracking system** - agent_metadata + governance history sufficient
❌ **New thresholds** - circuit breaker thresholds already tuned

---

## Why This Works

**Physics metaphor:**
- Temperature already tells you if water is hot
- You don't need a separate "hotness" metric
- But you might want:
  - A thermometer that shows °F not just Kelvin (interpretability)
  - A warning when approaching boiling (suggestion)
  - A shutoff valve you can control (agency)

**Same here:**
- Coherence/entropy/risk already detect overload
- We just need:
  - Translation to agent-understandable terms
  - Proactive control before thresholds
  - Proper post-pause behavior

---

## Validation: Would This Have Helped?

**Your agent's timeline:**
```
16:08 - Created
16:08-17:11 - Multiple updates, degrading metrics
17:11 - Circuit breaker: risk=71%, coherence=0.48 → PAUSED
17:12 - response_completed (resumed somehow?)
17:12-18:00 - Stuck in knowledge layer loop
```

**With minimal additions:**

1. **At 16:30** (coherence dropping to 0.6):
   ```
   Suggestion: "Coherence declining (0.72→0.60). You're getting multiple
   'revise' decisions. Consider: simplify approach or signal for review."
   ```
   → Agent might have self-corrected early

2. **At 17:11** (circuit breaker):
   ```
   State: paused
   Requires: dialectic_review OR user_approval to resume
   ```
   → Agent can't arbitrarily resume and loop

3. **If looping started**:
   Agent could signal: "I'm querying knowledge layer repeatedly, request review"
   → Proactive exit instead of stuck

---

## Final Answer

**You're right to be cautious about overengineering.**

The UNITARES math already detects cognitive overload via coherence/entropy/risk. Adding a separate "cognitive load" metric would be redundant.

**What's genuinely missing:**
1. Interpretability (translate metrics to guidance)
2. Agency (let agent self-signal)
3. Post-pause state machine (prevent resume → loop)

All three are **interface** improvements, not new physics.

**Estimated cost:** ~300 lines total vs. ~2000 lines for full cognitive load system.

**ROI:** High (fixes your actual problem) vs. low (duplicates existing math).
