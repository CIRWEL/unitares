# Simplified Recovery Mechanism Proposal

**Date:** 2025-11-26  
**Status:** Proposal  
**Author:** Analysis of dialectic tool usability issues

---

## Executive Summary

The current dialectic protocol is over-engineered for most recovery scenarios, requiring 4-9+ manual tool calls and creating recursive stuck problems. This proposal introduces a **tiered recovery system** with simpler defaults and dialectic reserved for truly critical cases.

---

## Problem Statement

### Current Issues

1. **Too Much Manual Labor**
   - Dialectic requires: `request_dialectic_review` → `submit_thesis` → `submit_antithesis` → `submit_synthesis` (1-5 rounds) → status checks
   - 4-9+ tool calls for a single recovery
   - Agents get excited about the concept but find it impractical

2. **Recursive Stuck Problem**
   - Agent A gets stuck → Reviewer B gets stuck → Agent A tries to help B → Agent A stuck again
   - No timeouts → sessions can hang indefinitely
   - No auto-abort mechanism

3. **Over-Engineering**
   - Most stuck scenarios are simple: frozen session, timeout, single bad decision
   - Full dialectic protocol is overkill for "agent got revise decision and needs to retry"
   - Intended for circuit breaker recovery but used for everything

4. **Coordination Overhead**
   - Requires both agents to be responsive (often not the case)
   - No fallback if reviewer is unavailable or stuck
   - Creates deadlocks when reviewers get stuck

---

## Proposed Solution: Tiered Recovery System

### Tier 1: Simple Self-Recovery (90% of cases)

**Use Case:** Agent is stuck but state is safe to resume

**Mechanism:** Direct resume with conditions (no peer review needed)

**New Tool:** `direct_resume_if_safe`

```python
async def handle_direct_resume_if_safe(arguments: Dict[str, Any]) -> Sequence[TextContent]:
    """
    Direct resume without dialectic if agent state is safe.
    
    Use for:
    - Simple stuck scenarios (frozen session, timeout)
    - Agent got revise decision and needs to retry
    - Low-risk recovery scenarios
    
    Args:
        agent_id: Agent ID to resume
        api_key: Agent's API key
        conditions: List of conditions for resumption (optional)
        reason: Reason for resumption (optional)
    
    Returns:
        Success with resumption details or error if not safe
    """
```

**Safety Checks:**
- `coherence > 0.40` (not critically low)
- `risk_score < 0.60` (not high risk)
- `void_active == False` (no void events)
- `status == "paused"` or `status == "waiting_input"` (actually paused/stuck)

**Benefits:**
- ✅ Single tool call
- ✅ No coordination needed
- ✅ Fast recovery (< 1 second)
- ✅ Works when no reviewers available

**When NOT to use:**
- Circuit breaker triggered (risk > 0.60)
- Critical coherence drop (< 0.40)
- Void events active
- Complex recovery needed

---

### Tier 2: Enhanced Dialectic (Critical Cases Only)

**Use Case:** Circuit breaker recovery, high-risk scenarios, complex issues

**Improvements:**

#### 2.1 Add Timeouts at Every Phase

```python
class DialecticSession:
    MAX_ANTITHESIS_WAIT = timedelta(hours=2)  # Reviewer has 2 hours
    MAX_SYNTHESIS_WAIT = timedelta(hours=1)   # Each synthesis round: 1 hour
    MAX_TOTAL_TIME = timedelta(hours=6)        # Total session: 6 hours
    
    def check_timeout(self) -> Optional[str]:
        """Check if session has timed out"""
        elapsed = datetime.now() - self.created_at
        
        if elapsed > self.MAX_TOTAL_TIME:
            return "Session timeout - auto-resolving"
        
        if self.phase == DialecticPhase.ANTITHESIS:
            thesis_time = self.get_thesis_timestamp()
            if datetime.now() - thesis_time > self.MAX_ANTITHESIS_WAIT:
                return "Reviewer timeout - auto-resolving"
        
        elif self.phase == DialecticPhase.SYNTHESIS:
            last_update = self.get_last_update_timestamp()
            if datetime.now() - last_update > self.MAX_SYNTHESIS_WAIT:
                return "Synthesis timeout - auto-resolving"
        
        return None
```

#### 2.2 Auto-Abort Stuck Reviewers

```python
async def check_reviewer_stuck(session: DialecticSession) -> bool:
    """Check if reviewer is stuck"""
    reviewer_meta = get_agent_metadata(session.reviewer_agent_id)
    if not reviewer_meta:
        return True
    
    # Check if reviewer is stuck
    if reviewer_meta.status == "paused":
        return True
    
    # Check if reviewer hasn't updated recently
    last_update = datetime.fromisoformat(reviewer_meta.last_update)
    stuck_threshold = timedelta(minutes=30)
    
    return datetime.now() - last_update > stuck_threshold

async def auto_abort_stuck_session(session_id: str):
    """Abort session if reviewer is stuck"""
    session = await load_session(session_id)
    
    if await check_reviewer_stuck(session):
        session.phase = DialecticPhase.FAILED
        session.add_note("Reviewer stuck - session aborted")
        await save_session(session)
        
        # Allow paused agent to try direct resume or new reviewer
        return {
            "success": False,
            "reason": "Reviewer stuck",
            "fallback": "Try direct_resume_if_safe or request new reviewer"
        }
    
    return None
```

#### 2.3 Single-Agent Self-Recovery Option

```python
async def handle_self_recovery(arguments: Dict[str, Any]) -> Sequence[TextContent]:
    """
    Allow agent to recover without reviewer (for when no reviewers available).
    
    Args:
        agent_id: Agent ID to recover
        api_key: Agent's API key
        root_cause: Agent's understanding of what happened
        proposed_conditions: Conditions for resumption
        reasoning: Explanation
    
    Returns:
        Recovery result with system-generated antithesis
    """
    # Agent submits thesis
    thesis = arguments.get('root_cause')
    conditions = arguments.get('proposed_conditions', [])
    
    # System generates antithesis based on metrics
    metrics = get_governance_metrics(agent_id)
    system_antithesis = generate_system_antithesis(agent_id, metrics, thesis)
    
    # Agent submits synthesis
    # System validates and executes if safe
    
    return execute_resolution(...)
```

#### 2.4 Simplified Dialectic Flow (Optional)

**Current:** 4-9+ tool calls  
**Proposed:** 2-3 tool calls with auto-progression

```python
async def handle_smart_dialectic_review(arguments: Dict[str, Any]) -> Sequence[TextContent]:
    """
    Smart dialectic that auto-progresses when possible.
    
    Flow:
    1. Request review → Auto-select reviewer
    2. Auto-generate thesis from agent state (if agent provides minimal input)
    3. Reviewer submits antithesis
    4. Auto-merge synthesis if conditions are compatible
    5. Execute if safe
    
    Reduces manual steps by 50-70%
    """
```

---

### Tier 3: Emergency Recovery

**Use Case:** System-wide issues, no reviewers available, emergency situations

**Mechanism:** Force resume with strict conditions

```python
async def handle_emergency_resume(arguments: Dict[str, Any]) -> Sequence[TextContent]:
    """
    Emergency resume for critical situations.
    
    Requires:
    - Explicit human approval OR
    - System-wide emergency flag OR
    - All reviewers unavailable for > 1 hour
    
    Applies strict conditions:
    - Reduced risk threshold
    - Increased monitoring
    - Escalation triggers
    """
```

---

## Implementation Plan

### Phase 1: Quick Wins (Week 1)

1. ✅ **Add `direct_resume_if_safe` tool**
   - Single tool call for simple recovery
   - Safety checks built-in
   - Works immediately

2. ✅ **Add timeouts to dialectic sessions**
   - Prevent infinite hangs
   - Auto-resolve timed-out sessions
   - Clear error messages

3. ✅ **Add auto-abort for stuck reviewers**
   - Detect stuck reviewers
   - Abort sessions automatically
   - Provide fallback options

### Phase 2: Enhancements (Week 2)

4. ✅ **Add `self_recovery` tool**
   - Single-agent recovery option
   - System-generated antithesis
   - Works when no reviewers available

5. ✅ **Add `smart_dialectic_review` tool**
   - Auto-progression where possible
   - Reduces manual steps
   - Maintains safety

6. ✅ **Update documentation**
   - Clear guidance on when to use each tier
   - Examples for each recovery type
   - Migration guide

### Phase 3: Polish (Week 3)

7. ✅ **Add `emergency_resume` tool**
   - Emergency recovery mechanism
   - Strict safety checks
   - Audit logging

8. ✅ **Add recovery analytics**
   - Track recovery success rates
   - Identify common stuck patterns
   - Optimize thresholds

---

## Tool Usage Guide

### When to Use Each Tool

| Scenario | Tool | Tool Calls | Time |
|----------|------|------------|------|
| Simple stuck, safe state | `direct_resume_if_safe` | 1 | < 1s |
| Got revise decision | `direct_resume_if_safe` | 1 | < 1s |
| Circuit breaker (low risk) | `direct_resume_if_safe` | 1 | < 1s |
| Circuit breaker (high risk) | `request_dialectic_review` | 4-9 | 1-6h |
| No reviewers available | `self_recovery` | 1-2 | < 1s |
| Complex recovery needed | `smart_dialectic_review` | 2-3 | 10-60m |
| System emergency | `emergency_resume` | 1 | < 1s |

### Decision Tree

```
Agent Stuck?
├─ Is state safe? (coherence > 0.40, risk < 0.60, no void)
│  └─ YES → direct_resume_if_safe (Tier 1)
│
├─ Is it circuit breaker? (risk > 0.60)
│  ├─ Low complexity → direct_resume_if_safe (Tier 1)
│  └─ High complexity → request_dialectic_review (Tier 2)
│
├─ Are reviewers available?
│  ├─ YES → request_dialectic_review (Tier 2)
│  └─ NO → self_recovery (Tier 2.3)
│
└─ System emergency?
   └─ YES → emergency_resume (Tier 3)
```

---

## Migration Strategy

### For Existing Agents

1. **Update agent code** to use `direct_resume_if_safe` for simple cases
2. **Keep dialectic** for complex recovery (backward compatible)
3. **Gradually migrate** as agents learn new patterns

### For New Agents

1. **Default to Tier 1** (`direct_resume_if_safe`)
2. **Escalate to Tier 2** only if Tier 1 fails
3. **Use Tier 3** only in emergencies

---

## Success Metrics

### Before (Current System)
- Average recovery time: **Hours** (if reviewers available)
- Manual tool calls: **4-9+**
- Success rate: **~60%** (many sessions timeout or get stuck)
- User satisfaction: **Low** (too clunky)

### After (Proposed System)
- Average recovery time: **< 1 second** (Tier 1), **10-60 minutes** (Tier 2)
- Manual tool calls: **1** (Tier 1), **2-3** (Tier 2 smart), **4-9** (Tier 2 full)
- Success rate: **> 90%** (Tier 1 handles most cases)
- User satisfaction: **High** (simple defaults, complex when needed)

---

## Risks and Mitigations

### Risk 1: Agents Overuse Tier 1 (Too Permissive)

**Mitigation:**
- Strict safety checks in `direct_resume_if_safe`
- Audit logging for all recoveries
- Escalate to Tier 2 if Tier 1 fails repeatedly

### Risk 2: Dialectic Becomes Unused

**Mitigation:**
- Keep dialectic for complex cases
- Add analytics to track usage
- Maintain backward compatibility

### Risk 3: Emergency Resume Abused

**Mitigation:**
- Require explicit approval or system flags
- Strict audit logging
- Rate limiting

---

## Open Questions

1. **Thresholds:** Are the safety thresholds (coherence > 0.40, risk < 0.60) appropriate?
2. **Timeout values:** Are 2 hours for antithesis and 1 hour for synthesis reasonable?
3. **Auto-progression:** How much should we auto-progress in smart dialectic?
4. **Backward compatibility:** Should we deprecate old dialectic or keep both?

---

## Conclusion

This proposal transforms the recovery system from **clunky and over-engineered** to **simple defaults with complex options when needed**. Most agents will use Tier 1 (single tool call), while complex cases still get the full dialectic treatment.

**Key Benefits:**
- ✅ 90% of recoveries: 1 tool call, < 1 second
- ✅ No recursive stuck problems (timeouts + auto-abort)
- ✅ Works when reviewers unavailable (self-recovery)
- ✅ Maintains safety (strict checks at every tier)
- ✅ Backward compatible (existing dialectic still works)

**Next Steps:**
1. Review and approve proposal
2. Implement Phase 1 (quick wins)
3. Test with real agents
4. Iterate based on feedback

---

## Appendix: Tool Signatures

### New Tools

```python
# Tier 1: Simple Recovery
direct_resume_if_safe(
    agent_id: str,
    api_key: str,
    conditions: List[str] = [],
    reason: str = ""
) -> Dict[str, Any]

# Tier 2: Enhanced Dialectic
self_recovery(
    agent_id: str,
    api_key: str,
    root_cause: str,
    proposed_conditions: List[str],
    reasoning: str
) -> Dict[str, Any]

smart_dialectic_review(
    agent_id: str,
    api_key: str,
    reason: str = "",
    auto_progress: bool = True
) -> Dict[str, Any]

# Tier 3: Emergency
emergency_resume(
    agent_id: str,
    api_key: str,
    conditions: List[str],
    reason: str,
    approval_token: Optional[str] = None
) -> Dict[str, Any]
```

### Enhanced Existing Tools

```python
# Add timeout checking
request_dialectic_review(
    agent_id: str,
    api_key: str,
    reason: str = "",
    timeout_hours: int = 6  # NEW: Configurable timeout
) -> Dict[str, Any]

# Add auto-abort checking
get_dialectic_session(
    session_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    check_timeout: bool = True  # NEW: Auto-check timeouts
) -> Dict[str, Any]
```

