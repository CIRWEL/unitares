# Governance Heartbeats for Mixed Autonomy Patterns

**Created:** November 26, 2025
**Context:** Tools grew from 6→40 because they're for agents, not users. But most agents are still user-prompted, not fully autonomous.

---

## The Reality: Mixed Autonomy

### Spectrum of Agent Behavior

```
User-Prompted (Low Autonomy)          Autonomous (High Autonomy)
─────────────────────────────────────────────────────────
│                    │                    │
User types            User asks           Agent decides
every action   →     what to do    →     & executes
Agent just            Agent chooses       independently
executes              tools/approach
│                    │                    │
Most common          Some agents          Rare (future)
```

**Your observation:** "I usually have to prompt tools and actions"

**Implication:** Tool-call-based governance triggers won't capture most work!

---

## What Actually Constitutes "Work"?

### For User-Prompted Agents
```
User: "Fix this bug"
Agent: [Thinks 30 seconds]
       [Reads 5 files]
       [Reasons about solution]
       [Proposes fix]

Tool calls: 0
Actual work: High cognitive load
Current governance: Not tracked (no process_agent_update)
```

### For Autonomous Agents
```
Agent: [Decides to test edge cases]
       [Calls 10 MCP tools]
       [Writes files]
       [Runs tests]

Tool calls: 10
Actual work: High cognitive load
Current governance: Might be tracked (if agent remembers to call)
```

**Both are doing work, but only one leaves tool-call traces!**

---

## Proposed Solution: Activity-Based Heartbeats

### Trigger Governance On:

1. **Conversation turns** (works for prompted agents)
2. **Tool calls** (works for autonomous agents)
3. **Time elapsed** (works for both)
4. **Explicit requests** (works for both)

```python
class GovernanceUpdateTrigger(Enum):
    MANUAL = "manual"                    # Agent explicitly calls
    CONVERSATION_TURN = "turn"           # After N user-agent exchanges
    TOOL_THRESHOLD = "tools"             # After N tool calls
    TIME_ELAPSED = "time"                # After N minutes
    HIGH_IMPACT_TOOL = "critical_tool"   # Always trigger on write/execute
    RESPONSE_LENGTH = "length"           # Long response = high effort
```

### Implementation: Activity Tracker

```python
@dataclass
class AgentActivity:
    """Track agent activity between governance updates"""
    agent_id: str

    # Counters
    conversation_turns: int = 0          # User prompts + agent responses
    tool_calls: int = 0                  # MCP tool invocations
    tokens_generated: int = 0            # Approximate cognitive effort
    files_modified: int = 0              # High-impact actions

    # Timestamps
    last_governance_update: str = None
    last_activity: str = None
    session_start: str = None

    # Complexity tracking
    cumulative_complexity: float = 0.0   # Sum of complexities

    def should_trigger_update(self) -> Tuple[bool, str]:
        """Determine if governance update should trigger"""

        # Rule 1: Every 5 conversation turns (prompted agents)
        if self.conversation_turns >= 5:
            return True, "conversation_turn_threshold"

        # Rule 2: Every 10 tool calls (autonomous agents)
        if self.tool_calls >= 10:
            return True, "tool_call_threshold"

        # Rule 3: Every 15 minutes
        if self.last_governance_update:
            elapsed = (now() - parse_datetime(self.last_governance_update)).total_seconds() / 60
            if elapsed >= 15:
                return True, "time_threshold"

        # Rule 4: High cumulative complexity
        if self.cumulative_complexity >= 3.0:
            return True, "complexity_threshold"

        # Rule 5: File modifications (high impact)
        if self.files_modified >= 3:
            return True, "high_impact_actions"

        return False, None

    def reset_after_update(self):
        """Reset counters after governance update"""
        self.conversation_turns = 0
        self.tool_calls = 0
        self.tokens_generated = 0
        self.files_modified = 0
        self.cumulative_complexity = 0.0
        self.last_governance_update = now().isoformat()
```

---

## Integration Points

### 1. Track Conversation Turns (For Prompted Agents)

**Where:** MCP server sees tool calls, but not conversation turns directly.

**Solution:** Infer from tool calls to `process_agent_update` or other MCP tools:

```python
# In MCP server wrapper
@tool_wrapper
def handle_any_mcp_tool(tool_name: str, args: Dict):
    agent_id = args.get('agent_id')

    # Track activity
    if agent_id:
        activity = get_or_create_activity(agent_id)
        activity.tool_calls += 1
        activity.last_activity = now().isoformat()

        # Estimate conversation turn (heuristic)
        # If time since last tool > 30 seconds, likely new user prompt
        if activity.last_activity:
            gap = (now() - parse_datetime(activity.last_activity)).total_seconds()
            if gap > 30:  # New conversation turn
                activity.conversation_turns += 1

        # Check if should trigger governance
        should_trigger, reason = activity.should_trigger_update()

        if should_trigger and tool_name != "process_agent_update":
            # Auto-inject lightweight heartbeat
            inject_governance_heartbeat(
                agent_id=agent_id,
                trigger_reason=reason,
                activity=activity
            )

    # Execute actual tool
    return execute_tool(tool_name, args)
```

### 2. Lightweight Heartbeat vs Full Update

```python
def inject_governance_heartbeat(agent_id: str, trigger_reason: str, activity: AgentActivity):
    """Lightweight governance update - minimal overhead"""

    # Don't require full 128-dim params
    # Just track high-level metrics

    heartbeat_update(
        agent_id=agent_id,
        trigger=trigger_reason,

        # Estimated metrics (not full UNITARES)
        estimated_complexity=activity.cumulative_complexity / max(activity.conversation_turns, 1),
        tool_call_rate=activity.tool_calls / max(activity.conversation_turns, 1),
        activity_summary={
            'turns': activity.conversation_turns,
            'tools': activity.tool_calls,
            'files': activity.files_modified
        },

        # Agent can still provide full params if available
        full_params=None  # Optional
    )
```

### 3. Preserve Manual Control

```python
# Agents can still explicitly call full governance
process_agent_update(
    agent_id="...",
    parameters=[...],  # Full 128-dim
    ethical_drift=[...],  # Full 3-dim
    response_text="...",
    complexity=0.7
)

# But also support lightweight calls
process_agent_update(
    agent_id="...",
    # Minimal - just signal activity
    response_text="Analyzed 3 files, found 2 bugs",
    complexity=0.5
)
```

---

## Example Scenarios

### Scenario 1: Prompted Agent (Your Most Common Case)

```
[09:00] User: "Debug this issue"
        Agent: Thinks, reads files, analyzes
        Activity: turns=1, tools=0, complexity=0.6
        Governance: Not triggered yet

[09:05] User: "Try this approach"
        Agent: Tests, iterates, responds
        Activity: turns=2, tools=0, complexity=1.3
        Governance: Not triggered yet

[09:10] User: "What about edge cases?"
        Agent: Deep analysis, multiple scenarios
        Activity: turns=3, tools=0, complexity=2.1
        Governance: Not triggered yet

[09:15] User: "Implement the fix"
        Agent: Writes code, explains
        Activity: turns=4, tools=1 (write), complexity=2.7, files=1
        Governance: Not triggered yet

[09:20] User: "Test it"
        Agent: Runs tests, reports results
        Activity: turns=5, tools=2, complexity=3.2
        ✅ Governance: TRIGGERED (turn threshold + complexity threshold)

        Heartbeat injected:
        {
            "trigger": "conversation_turn_threshold",
            "turns_since_last": 5,
            "estimated_complexity": 0.64,
            "tool_calls": 2,
            "files_modified": 1,
            "duration_minutes": 20
        }
```

### Scenario 2: Autonomous Agent (Future/Rare)

```
[10:00] Agent: Decides to refactor module
        Calls 8 MCP tools (read, analyze, search)
        Activity: turns=0, tools=8, complexity=1.2
        Governance: Not triggered yet

[10:05] Agent: Implements changes
        Calls 5 more tools (write, edit)
        Activity: turns=0, tools=13, files=3
        ✅ Governance: TRIGGERED (tool threshold + file threshold)
```

### Scenario 3: Mixed (Some autonomy)

```
[11:00] User: "Optimize performance"
        Agent: Autonomously profiles, tests 5 approaches
        Activity: turns=1, tools=12, complexity=0.8, files=2
        ✅ Governance: TRIGGERED (tool threshold)
```

---

## Implementation Plan

### Phase 1: Activity Tracking Infrastructure (Week 1)

```python
# Add to mcp_server_std.py

# Global activity tracker
agent_activities: Dict[str, AgentActivity] = {}

def get_or_create_activity(agent_id: str) -> AgentActivity:
    if agent_id not in agent_activities:
        agent_activities[agent_id] = AgentActivity(
            agent_id=agent_id,
            session_start=now().isoformat()
        )
    return agent_activities[agent_id]

def track_activity(agent_id: str, activity_type: str, **kwargs):
    """Track agent activity"""
    activity = get_or_create_activity(agent_id)

    if activity_type == "tool_call":
        activity.tool_calls += 1
    elif activity_type == "turn":
        activity.conversation_turns += 1
    elif activity_type == "complexity":
        activity.cumulative_complexity += kwargs.get('complexity', 0)
    elif activity_type == "file_modify":
        activity.files_modified += 1

    activity.last_activity = now().isoformat()

    # Check if should trigger
    should_trigger, reason = activity.should_trigger_update()
    return should_trigger, reason
```

### Phase 2: MCP Tool Wrapper (Week 1)

```python
# Wrap all MCP tool calls

async def handle_tool_with_tracking(tool_name: str, arguments: Dict[str, Any]):
    """Wrapper that adds activity tracking"""

    agent_id = arguments.get('agent_id')

    # Track this tool call
    if agent_id:
        should_trigger, reason = track_activity(agent_id, "tool_call")

        # Special handling for high-impact tools
        if tool_name in ['write', 'edit', 'bash']:
            track_activity(agent_id, "file_modify")

        # Auto-inject heartbeat if needed
        if should_trigger and tool_name != "process_agent_update":
            await inject_governance_heartbeat(agent_id, reason)

    # Execute actual tool
    return await execute_actual_tool(tool_name, arguments)
```

### Phase 3: Heartbeat Implementation (Week 2)

```python
async def inject_governance_heartbeat(agent_id: str, trigger_reason: str):
    """Inject lightweight governance update"""

    activity = agent_activities.get(agent_id)
    if not activity:
        return

    # Create minimal governance update
    await handle_process_agent_update({
        'agent_id': agent_id,
        'heartbeat': True,  # Flag as lightweight
        'trigger_reason': trigger_reason,
        'activity_summary': {
            'conversation_turns': activity.conversation_turns,
            'tool_calls': activity.tool_calls,
            'files_modified': activity.files_modified,
            'cumulative_complexity': activity.cumulative_complexity,
            'duration_minutes': get_session_duration(activity)
        },
        # Optional: agent can still provide full params
        'parameters': None,  # Will use defaults
        'ethical_drift': None,
        'response_text': f"Heartbeat ({trigger_reason})",
        'complexity': activity.cumulative_complexity / max(activity.conversation_turns, 1)
    })

    # Reset counters
    activity.reset_after_update()
```

### Phase 4: Modified process_agent_update (Week 2)

```python
# In handle_process_agent_update

async def handle_process_agent_update(arguments: Dict[str, Any]):
    agent_id = arguments.get('agent_id')
    is_heartbeat = arguments.get('heartbeat', False)

    if is_heartbeat:
        # Lightweight path
        # - Use estimated complexity
        # - Use default params (don't require 128-dim)
        # - Still track in history (but marked as heartbeat)
        # - Update metadata counters
        # - Check circuit breakers

        return await process_heartbeat_update(arguments)
    else:
        # Full governance update (current behavior)
        return await process_full_update(arguments)
```

---

## Configuration

### Tunable Thresholds

```python
# config/governance_config.py

@dataclass
class HeartbeatConfig:
    """Configuration for automatic governance heartbeats"""

    # Trigger thresholds
    conversation_turn_threshold: int = 5      # Every 5 user-agent exchanges
    tool_call_threshold: int = 10            # Every 10 MCP tool calls
    time_threshold_minutes: int = 15         # Every 15 minutes
    complexity_threshold: float = 3.0        # Cumulative complexity
    file_modification_threshold: int = 3     # File writes/edits

    # Heartbeat behavior
    enabled: bool = True                     # Master switch
    track_conversation_turns: bool = True    # Infer from tool timing
    track_tool_calls: bool = True           # Count MCP calls
    track_complexity: bool = True           # Sum complexity estimates

    # High-impact tools (always track)
    high_impact_tools: List[str] = [
        'write', 'edit', 'bash',
        'export_to_file', 'request_dialectic_review'
    ]
```

---

## Benefits

### For Prompted Agents (Your Current Reality)
✅ Captures work even without tool calls
✅ Conversation turns = actual cognitive load
✅ Time-based ensures no agent goes dark
✅ No agent cooperation needed (automatic)

### For Autonomous Agents (Future)
✅ Tool-based triggers catch autonomous work
✅ File modifications = high-impact tracking
✅ Complexity accumulation = strain detection

### For Both
✅ Agents can still manually call (preserve autonomy)
✅ Lightweight (no 128-dim params required)
✅ Gradual rollout (configurable thresholds)
✅ Visibility (all agents tracked, none invisible)

---

## Rollout Strategy

### Stage 1: Observation Only (Week 1)
- Add activity tracking
- Log what WOULD trigger
- Don't inject heartbeats yet
- Analyze patterns

### Stage 2: Opt-In Heartbeats (Week 2)
- Enable for test agents
- Verify overhead is acceptable
- Tune thresholds based on data

### Stage 3: Default On (Week 3)
- Enable for all new agents
- Existing agents can opt-in
- Monitor metrics

### Stage 4: Analyze Impact (Week 4)
- Compare coverage before/after
- Measure overhead
- Adjust thresholds
- Document patterns

---

## Open Questions

1. **Conversation turn inference:** Can we accurately detect turns from tool timing alone?
   - Alternative: Add explicit turn tracking to MCP protocol

2. **Heartbeat vs full update ratio:** What's healthy?
   - 80% heartbeats, 20% full?
   - Or 50/50?

3. **Opt-out mechanism:** Should agents be able to disable heartbeats?
   - For debugging?
   - For low-stakes work?

4. **Retroactive tracking:** Should we backfill heartbeats for existing agents?
   - Or only track going forward?

---

**Status:** Design complete, ready for Phase 1 implementation
**Next:** Implement activity tracking infrastructure
